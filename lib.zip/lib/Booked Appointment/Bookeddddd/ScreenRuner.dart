
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_locales/flutter_locales.dart';
import 'package:geocoding/geocoding.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';
import 'package:untitled1/Booked%20Appointment/Bookeddddd/screens/home_screen.dart';
import 'package:untitled1/sign%20in/homeScreen.dart';
import '../../home Visit/HomeVisitDetails/pages/todosHome.dart';
import '../../home Visit/HomeVisitDetails/providers/todo_providerHome.dart';
import '../../screens/asset.dart';
import '../../settings/FeedBackDetails/pages/todosFeed.dart';
import '../../settings/FeedBackDetails/providers/todo_providerFeed.dart';
import '../../sign in/Reg.dart';
import '../../sign in/phone Auth/phone.dart';
import '../locations.dart';
import 'app/app.dart';
class TodoListHome extends StatefulWidget {
  const TodoListHome({super.key});

  @override
  State<TodoListHome> createState() => _TodoListHomeState();
}
class _TodoListHomeState extends State<TodoListHome> {


  @override
  Widget build(BuildContext context) {


    return MultiProvider(
        providers:[
          ChangeNotifierProvider(
            create:(context)=>TodoProviderHome(),),
          ChangeNotifierProvider(
            create:(context)=>TodoProviderFeed(),),
        ],
        builder:(context,child) {
 return LocaleBuilder(
              builder: (locale) =>
                  MaterialApp(
                      debugShowCheckedModeBanner: false,
                      title: 'Flutter Locales',
                      localizationsDelegates:
                      Locales.delegates,
                      supportedLocales: Locales.supportedLocales,
                      locale: locale,
                   home:LogInPage (),

                  )
          );
        }
    );
  }
}

