import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:untitled1/Booked%20Appointment/Bookeddddd/data/datasource/task_datasource.dart';

final taskDatasourceProvider = Provider<TaskDatasource>((ref) {
  return TaskDatasource();
});
