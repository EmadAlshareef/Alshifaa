import 'package:flutter/material.dart';
import 'package:flutter_locales/flutter_locales.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:untitled1/Booked%20Appointment/Bookeddddd/utils/extensions.dart';
import '../config/config.dart';

class FlutterRiverpodTodoApp extends ConsumerWidget {
  const FlutterRiverpodTodoApp({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final route = ref.watch(routesProvider);

    return MaterialApp.router(
      debugShowCheckedModeBanner: false,
      theme: AppTheme.light,
      routerConfig: route,

    );
  }
}
class rrr extends StatelessWidget {
  const rrr({super.key});


  @override
  Widget build(BuildContext context) {
    final colors = context.colorScheme;
   return Scaffold(appBar: AppBar(
     backgroundColor: colors.primary,
   title: LocaleText("app list",
    style: context.textTheme.headlineSmall?.copyWith(
        fontWeight: FontWeight.bold,
      fontSize: 26,
   ),
   )
   ),
     body:


        FlutterRiverpodTodoApp());


  }
}
