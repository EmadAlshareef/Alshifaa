
import 'package:flutter/material.dart';
import 'package:flutter_locales/flutter_locales.dart';
import 'package:google_fonts/google_fonts.dart';

import '../admin&pharmacstic/aadminHomePage.dart';
import 'Bookeddddd/app/app.dart';
import 'Doctors.dart';
import 'locations.dart';


class bookapp extends StatelessWidget {
  const bookapp({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: hexStringToColor("5E61F4"),
        elevation: 0,
        centerTitle: true,
        title: LocaleText("clinic",
          style: TextStyle(
            fontWeight: FontWeight.bold,
          ),
        ),
        leading: BackButton(
          onPressed:(){
            Navigator.push(context,
              MaterialPageRoute(
                builder: (context)=>locations(),),);
          },
        ),
        actions: [IconButton(onPressed: (){

          Navigator.push(context,
            MaterialPageRoute(
              builder: (context)=>Doctors(),),
          );
        }, icon: Icon(Icons.person),)],

      ),
      body: SingleChildScrollView(
        scrollDirection: Axis.vertical,
        child: Container(
          width: double.infinity,

          decoration: BoxDecoration(
              gradient: LinearGradient(colors: [
                hexStringToColor("5E61F4"),
                hexStringToColor("9546C4"),

              ], begin: Alignment.topCenter, end: Alignment.bottomCenter)),
          child:  Column(
            children: [
              const  SizedBox(height: 20,),
              Padding(
                padding: const EdgeInsets.all(0.0),
                child: ElevatedButton(

                  onPressed: (){
                    Navigator.push(context,
                      MaterialPageRoute(
                        builder: (context)=> rrr()));
                  },
                  child: LocaleText(
                    "general",
                    style: GoogleFonts.robotoCondensed(
                      fontSize: 23,
                      fontWeight: FontWeight.w500,
                      color: Colors.blueAccent,

                    ),
                  ),
                  style:ElevatedButton.styleFrom(
                    backgroundColor: Colors.white,
                    padding:EdgeInsets.fromLTRB(90,30,90,30),
                  ),
                ),
              ),
              const  SizedBox(height: 20,),
              Padding(
                padding: const EdgeInsets.all(0.0),
                child: ElevatedButton(

                  onPressed: (){
                    Navigator.push(context,
                      MaterialPageRoute(
                        builder: (context)=>rrr()));
                  },
                  child: LocaleText(
                    "Pe",
                    style: GoogleFonts.robotoCondensed(
                      fontSize: 23,
                      fontWeight: FontWeight.w500,
                      color: Colors.blueAccent,

                    ),
                  ),
                  style:ElevatedButton.styleFrom(
                    backgroundColor: Colors.white,
                    padding:EdgeInsets.fromLTRB(125,30,125,30),
                  ),
                ),
              ),
              const  SizedBox(height: 20,),
              Padding(
                padding: const EdgeInsets.all(0.0),
                child: ElevatedButton(

                  onPressed: (){
                    Navigator.push(context,
                      MaterialPageRoute(
                        builder: (context)=> rrr()));
                  },
                  child: LocaleText(
                    "ps" ,
                    style: GoogleFonts.robotoCondensed(
                      fontSize: 23,
                      fontWeight: FontWeight.w500,
                      color: Colors.blueAccent,

                    ),
                  ),
                  style:ElevatedButton.styleFrom(
                    backgroundColor: Colors.white,
                    padding:EdgeInsets.fromLTRB(125,30,125,30),
                  ),
                ),
              ),
              const  SizedBox(height: 20,),
              Padding(
                padding: const EdgeInsets.all(0.0),
                child: ElevatedButton(

                  onPressed: (){
                    Navigator.push(context,
                      MaterialPageRoute(
                        builder: (context)=> rrr()));
                  },
                  child: LocaleText(
                    "ph",
                    style: GoogleFonts.robotoCondensed(
                      fontSize: 23,
                      fontWeight: FontWeight.w500,
                      color: Colors.blueAccent,

                    ),
                  ),
                  style:ElevatedButton.styleFrom(
                    backgroundColor: Colors.white,
                    padding:EdgeInsets.fromLTRB(100,30,100,30),
                  ),
                ),
              ),
              const  SizedBox(height: 20,),
              Padding(
                padding: const EdgeInsets.all(0.0),
                child: ElevatedButton(

                  onPressed: (){
                    Navigator.push(context,
                      MaterialPageRoute(
                        builder: (context)=> rrr()));
                  },
                  child: LocaleText(
                    "gy",
                    style: GoogleFonts.robotoCondensed(
                      fontSize: 23,
                      fontWeight: FontWeight.w500,
                      color: Colors.blueAccent,

                    ),
                  ),
                  style:ElevatedButton.styleFrom(
                    backgroundColor: Colors.white,
                    padding:EdgeInsets.fromLTRB(120,30,120,30),
                  ),
                ),
              ),
              const  SizedBox(height: 20,),
              Padding(
                padding: const EdgeInsets.all(0.0),
                child: ElevatedButton(

                  onPressed: (){
                    Navigator.push(context,
                      MaterialPageRoute(
                        builder: (context)=> rrr()));
                  },
                  child: LocaleText(
                    "la" ,
                    style: GoogleFonts.robotoCondensed(
                      fontSize: 23,
                      fontWeight: FontWeight.w500,
                      color: Colors.blueAccent,

                    ),
                  ),
                  style:ElevatedButton.styleFrom(
                    backgroundColor: Colors.white,
                    padding:EdgeInsets.fromLTRB(115,30,115,30),
                  ),
                ),
              ),
              const  SizedBox(height: 50,),


            ],),
        ),
      ),

    );
  }
}
hexStringToColor(String hexColor) {
  hexColor = hexColor.toUpperCase().replaceAll("#", "");
  if (hexColor.length == 6) {
    hexColor = "FF" + hexColor;
  }
  return Color(int.parse(hexColor, radix: 16));
}