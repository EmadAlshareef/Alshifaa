import 'package:flutter/material.dart';
import 'package:flutter_locales/flutter_locales.dart';

import '../admin&pharmacstic/aadminHomePage.dart';

class Doctors extends StatefulWidget {
  const Doctors({super.key});
  @override
  State<Doctors> createState() => _DoctorsState();
}

class _DoctorsState extends State<Doctors> {
  static List<String> Name=['Ahmed_Otoom-General_medicine','Khaled_AlMakademh-Pediatrics','Bashar_AlShboul-Psychiatry','Emad-Alshareef-General_medicine','Rawan_AlShareware-hysical_therapy','Yasmeen_Salma-Gynecology','Sara_Anees-Laboratories',];
  static List<String> times=['8:00AM-1:00PM','8:00AM-1:00PM','8:00AM-1:00PM','8:00AM-1:00PM','8:00AM-1:00PM','8:00AM-1:00PM','8:00AM-1:00PM',];
  static List<String> specialties=['General medicine','Pediatrics','General medicine','Psychiatry','hysical therapy','Gynecology','Laboratories',];
  static List url =['https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRripLcqGUKIBfgbtmux6U1UY9UkgezqzJzFw&s',
  'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRripLcqGUKIBfgbtmux6U1UY9UkgezqzJzFw&s',
    'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRripLcqGUKIBfgbtmux6U1UY9UkgezqzJzFw&s',
    'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRripLcqGUKIBfgbtmux6U1UY9UkgezqzJzFw&s',
    'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRripLcqGUKIBfgbtmux6U1UY9UkgezqzJzFw&s'
    ,'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSEGCJ7ZqR5kyDCn0BB98BjI4pKGxgPRH2ZVA&s'
    ,'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSEGCJ7ZqR5kyDCn0BB98BjI4pKGxgPRH2ZVA&s',
    'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSEGCJ7ZqR5kyDCn0BB98BjI4pKGxgPRH2ZVA&s'];


    final List<Doctorss> doctors = List.generate(Name.length, (index) =>
    Doctorss('${Name[index]}',
         '${times[index]}'
    , '${specialties[index]}',
        '${url[index]}'
    ));

  @override
  Widget build(BuildContext context) {
    return Scaffold(appBar: AppBar(
      centerTitle: true,
      backgroundColor: hexStringToColor("5E61F4"),
      title:  LocaleText("doctors"),

    ),

    body:
    ListView.builder(itemCount: doctors.length,
            itemBuilder: (context,index){
      return Card(
        child: ListTile(title: Text(doctors[index].name,style: TextStyle( fontWeight: FontWeight.bold),),
          leading: SizedBox(width: 50, height: 200,
          child: Image.network(doctors[index].url),),





        ),
      );

            }






    ));


  }
}
class Doctorss {
  final String name;
  final String specialties;
  final String times;
  final String url;


  Doctorss(this.name,
      this.specialties,
      this.times,
      this.url,);


}