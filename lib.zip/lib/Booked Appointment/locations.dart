import 'package:flutter/material.dart';
import 'package:flutter_locales/flutter_locales.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../maps/static_locationAmman.dart';
import '../../maps/static_locationAqabe.dart';
import '../../maps/static_locationIrbid.dart';
import '../../maps/static_locationMadaba.dart';
import '../../maps/static_locationRamtha.dart';
import '../../maps/static_locationZarqa.dart';
import '../../screens/asset.dart';
import '../../settings/settings.dart';



class locations extends StatelessWidget {
  const locations({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: hexStringToColor("5E61F4"),
        elevation: 0,
        title: LocaleText("locations",
          style: TextStyle(
            fontWeight: FontWeight.bold,
          ),
        ),
        leading: BackButton(
          onPressed:(){
            Navigator.push(context,
              MaterialPageRoute(
                builder: (context)=>HomeScreen(),),);
          },
        ),
        actions: [IconButton(onPressed: (){

          Navigator.push(context,
            MaterialPageRoute(
              builder: (context)=>settings(),),
          );
        }, icon: Icon(Icons.menu),)],

      ),
      body: SingleChildScrollView(
        scrollDirection: Axis.vertical,
        child: Container(
          width: double.infinity,

          decoration: BoxDecoration(
              gradient: LinearGradient(colors: [
                hexStringToColor("5E61F4"),
                hexStringToColor("9546C4"),

              ], begin: Alignment.topCenter, end: Alignment.bottomCenter)),
          child:  Column(
            children: [
              const  SizedBox(height: 20,),
              Padding(
                padding: const EdgeInsets.all(0.0),
                child: ElevatedButton(

                  onPressed: (){
                    Navigator.push(context,
                      MaterialPageRoute(
                        builder: (context)=>CustomMarkerInfoRamtha(),),);
                  },
                  child: LocaleText(
                    "ramtha" ,
                    style: GoogleFonts.robotoCondensed(
                      fontSize: 23,
                      fontWeight: FontWeight.w500,
                      color: Colors.blueAccent,

                    ),
                  ),
                  style:ElevatedButton.styleFrom(
                    backgroundColor: Colors.white,
                    padding:EdgeInsets.fromLTRB(115,30,115,30),
                  ),
                ),
              ),
              const  SizedBox(height: 20,),
              Padding(
                padding: const EdgeInsets.all(0.0),
                child: ElevatedButton(

                  onPressed: (){
                    Navigator.push(context,
                      MaterialPageRoute(
                        builder: (context)=>CustomMarkerInfoAmman(),),);
                  },
                  child: LocaleText(
                    "amman",
                    style: GoogleFonts.robotoCondensed(
                      fontSize: 23,
                      fontWeight: FontWeight.w500,
                      color: Colors.blueAccent,

                    ),
                  ),
                  style:ElevatedButton.styleFrom(
                    backgroundColor: Colors.white,
                    padding:EdgeInsets.fromLTRB(125,30,125,30),
                  ),
                ),
              ),
              const  SizedBox(height: 20,),
              Padding(
                padding: const EdgeInsets.all(0.0),
                child: ElevatedButton(

                  onPressed: (){
                    Navigator.push(context,
                      MaterialPageRoute(
                        builder: (context)=>CustomMarkerInfoZarqa (),),);
                  },
                  child: LocaleText(
                    "alzarqa" ,
                    style: GoogleFonts.robotoCondensed(
                      fontSize: 23,
                      fontWeight: FontWeight.w500,
                      color: Colors.blueAccent,

                    ),
                  ),
                  style:ElevatedButton.styleFrom(
                    backgroundColor: Colors.white,
                    padding:EdgeInsets.fromLTRB(115,30,115,30),
                  ),
                ),
              ),
              const  SizedBox(height: 20,),
              Padding(
                padding: const EdgeInsets.all(0.0),
                child: ElevatedButton(

                  onPressed: (){
                    Navigator.push(context,
                      MaterialPageRoute(
                        builder: (context)=>CustomMarkerInfoMadaba(),),);
                  },
                  child:LocaleText(
                    "maddaba" ,
                    style: GoogleFonts.robotoCondensed(
                      fontSize: 23,
                      fontWeight: FontWeight.w500,
                      color: Colors.blueAccent,

                    ),
                  ),
                  style:ElevatedButton.styleFrom(
                    backgroundColor: Colors.white,
                    padding:EdgeInsets.fromLTRB(115,30,115,30),
                  ),
                ),
              ),
              const  SizedBox(height: 20,),
              Padding(
                padding: const EdgeInsets.all(0.0),
                child: ElevatedButton(

                  onPressed: (){
                    Navigator.push(context,
                      MaterialPageRoute(
                        builder: (context)=>CustomMarkerInfoAqapa(),),);
                  },
                  child: LocaleText(
                    " alaqaba" ,
                    style: GoogleFonts.robotoCondensed(
                      fontSize: 23,
                      fontWeight: FontWeight.w500,
                      color: Colors.blueAccent,

                    ),
                  ),
                  style:ElevatedButton.styleFrom(
                    backgroundColor: Colors.white,
                    padding:EdgeInsets.fromLTRB(115,30,115,30),
                  ),
                ),
              ),
              const  SizedBox(height: 20,),
              Padding(
                padding: const EdgeInsets.all(0.0),
                child: ElevatedButton(

                  onPressed: (){
                    Navigator.push(context,
                      MaterialPageRoute(
                        builder: (context)=>CustomMarkerInfoIrbed(),),);
                  },
                  child: LocaleText(
                    "irbid" ,
                    style: GoogleFonts.robotoCondensed(
                      fontSize: 23,
                      fontWeight: FontWeight.w500,
                      color: Colors.blueAccent,

                    ),
                  ),
                  style:ElevatedButton.styleFrom(
                    backgroundColor: Colors.white,
                    padding:EdgeInsets.fromLTRB(140,30,140,30),
                  ),
                ),
              ),


            ],),
        ),
      ),

    );
  }
}
hexStringToColor(String hexColor) {
  hexColor = hexColor.toUpperCase().replaceAll("#", "");
  if (hexColor.length == 6) {
    hexColor = "FF" + hexColor;
  }
  return Color(int.parse(hexColor, radix: 16));
}