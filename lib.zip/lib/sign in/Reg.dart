

import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:awesome_dialog/awesome_dialog.dart';
import 'package:untitled1/sign%20in/user_fire/firease_auth_service.dart';

import '../screens/asset.dart';

var formKey = GlobalKey<FormState>();
class Reg extends StatefulWidget {
  @override
  _BmiScreenState createState() => _BmiScreenState();
}

class _BmiScreenState extends State<Reg> {

  final  firebaseAuthService _auth=firebaseAuthService();
  var emailController = TextEditingController();
  var nameController = TextEditingController();
  var phoneController = TextEditingController();
  var passwordController = TextEditingController();
  bool isSigningUp = false;
  double Year = 1990;
  Future _signUp() async {

    setState(() {
      isSigningUp = true;
    });

    String name=nameController.text.trim();
    String email=emailController.text.trim();
    String pass=passwordController.text.trim();
    User?user = await _auth.signUpWithEmailAndPassword(email,pass);
    setState(() {
      isSigningUp = false;
    });
    if(user !=null){
      AwesomeDialog(
        context: context,
        dialogType: DialogType.success,
        animType: AnimType.rightSlide,
        title: 'Success',
        desc: 'User is successfully signed in',
        btnOkOnPress: () {
          Navigator.push(context,
              MaterialPageRoute(
                  builder: (context)=> HomeScreen()));

        },
      ).show();

    }
    else{
      print("some error happend");

      AwesomeDialog(
        context: context,
        dialogType: DialogType.info,
        animType: AnimType.rightSlide,
        title: 'error',
        desc: 'some error happend',
        btnCancelOnPress: () {},
        btnOkOnPress: () {},
      )..show();

    }



  }

  @override
  void dispose() {
    nameController.dispose();
    emailController.dispose();
    phoneController.dispose();
    passwordController.dispose();
    super.dispose();
  }




  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        scrollDirection: Axis.vertical,
        child:

        Form(
          key: formKey,
          child: Column(
            children:
            [
              Image.asset('images/rectangle-1.png'),
              const SizedBox(height: 10,),

              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 8.0),
                child: TextFormField(

                  controller: nameController,
                  onFieldSubmitted: (String Value) {
                    print(Value);
                  },
                  validator: (value) {
                    if (value!.isEmpty) {
                      return 'name can not be empty';
                    }
                    return null;
                  },
                  decoration: InputDecoration(
                    labelText: 'Full name',
                    border: OutlineInputBorder(),
                  ),
                ),
              ),
              const SizedBox(height: 10,),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: TextFormField(
                  validator: (value) {
                    if (value!.isEmpty) {
                      return 'email address can not be empty';
                    }
                    return null;
                  },

                  controller: emailController,
                  keyboardType: TextInputType.emailAddress,

                  decoration: InputDecoration(
                    labelText: 'Email Address & phone Number',
                    border: OutlineInputBorder(),


                    suffixIcon: Icon(Icons.email,),
                  ),
                ),
              ),
              const SizedBox(height: 10,),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 8.0),
                child: TextFormField(
                  keyboardType: TextInputType.phone,
                  controller: phoneController,
                  onFieldSubmitted: (String Value) {
                    print(Value);
                  },
                  validator: (value) {
                    if (value!.isEmpty) {

                      return 'phone can not be empty';
                    }
                    return null;
                  },
                  decoration: InputDecoration(
                    suffixIcon: Icon(Icons.phone),
                    labelText: 'phone',
                    border: OutlineInputBorder(),
                  ),
                ),
              ),
              const SizedBox(height: 10,),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 8.0),
                child: TextFormField(
                  controller: passwordController,
                  keyboardType: TextInputType.visiblePassword,
                  obscureText: true,
                  onFieldSubmitted: (String Value) {
                    print(Value);
                  },
                  validator: (value) {
                    if (value!.isEmpty) {
                      return 'password can not be empty';
                    }
                    return null;
                  },
                  decoration: InputDecoration(
                    labelText: 'Set Password',
                    border: OutlineInputBorder(),

                    suffixIcon: Icon(Icons.lock,),

                  ),
                ),
              ),
              const SizedBox(height: 10,),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20.0,),

                child: Container(

                  child: Column(

                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        'Year Of born',
                        style: TextStyle(
                          fontSize: 15.0,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.baseline,
                        mainAxisAlignment: MainAxisAlignment.center,
                        textBaseline: TextBaseline.alphabetic,
                        children: [
                          Text(
                            '${Year.round()}',
                            style: TextStyle(
                              fontSize: 20.0,
                              fontWeight: FontWeight.w900,
                            ),
                          ),
                        ],
                      ),
                      Slider(
                        activeColor: Colors.blueAccent,
                        inactiveColor: Colors.black,
                        value: Year,
                        max: 2024.0,
                        min: 1960.0,
                        onChanged: (value) {
                          setState(() {
                            Year = value;
                          });
                        },
                      ),
                    ],
                  ),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(
                      10.0,
                    ),

                  ),
                ),
              ),
              const SizedBox(height: 20,),
              Padding(
                padding: const EdgeInsets.all(8.0),


                child: Container(


                  width: double.infinity,
                  color: Color.fromARGB(255, 111, 120, 255),
                  child: GestureDetector(
                    onTap: () {

                      _signUp();
                    },

                    child: isSigningUp ? CircularProgressIndicator(color: Colors.white,):
                    Text(
                      '                         Registration',
                      style: GoogleFonts.lato(
                        textStyle: Theme.of(context).textTheme.displayLarge,
                        fontSize: 26,
                        fontWeight: FontWeight.w700,
                        fontStyle: FontStyle.italic,
                      ),
                    ),
                  ),
                ),
              ),


            ],
          ),
        ),
      ),
    );
  }






}
