import 'package:flutter/material.dart';

import 'homeScreen.dart';



class SplashScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {

    Future.delayed(Duration(seconds: 3), () {

      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => homeScreen()),
      );
    });

    return Scaffold(
      body:
        Container(
        width: double.infinity,

        decoration: const BoxDecoration(
        gradient:
        LinearGradient(
        colors: [Colors.blue, Colors.white],
        begin: Alignment.topRight,
        end: Alignment.bottomLeft,
    ),
    ),child: Stack(
        fit: StackFit.expand,
        children: [
          Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Image.asset('images/iconOfapp.png'),
                Text(
                  '',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
        ),
    );
  }
}