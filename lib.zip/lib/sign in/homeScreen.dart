import 'package:flutter/material.dart';
import 'package:flutter_locales/flutter_locales.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:untitled1/sign%20in/signIn.dart';
import '../Booked Appointment/clinics.dart';
import 'admin_login.dart';
class homeScreen extends StatelessWidget {
  const homeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body:
      Container(
        width: double.infinity,

        decoration: BoxDecoration(
            gradient: LinearGradient(colors: [
              hexStringToColor("5E61F4"),
              hexStringToColor("9546C4"),

            ], begin: Alignment.topCenter, end: Alignment.bottomCenter)),
        child:  Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Image.asset('images/iconOfapp.png'),
            const  SizedBox(height: 20,),
            Padding(
              padding: const EdgeInsets.all(0.0),
              child: ElevatedButton(
                onPressed: (){
                  Navigator.push(context,
                    MaterialPageRoute(
                      builder: (context)=>LoginPage(),),);
                },
                child: LocaleText(
                  "login" ,
                  style: GoogleFonts.lato(
                    textStyle: Theme.of(context).textTheme.displayLarge,
                    fontSize: 26,
                    fontWeight: FontWeight.w700,
                    fontStyle: FontStyle.italic,
                  ),
                ),
                style:ElevatedButton.styleFrom(
                  backgroundColor: Colors.white,
                  padding:EdgeInsets.fromLTRB(140,30,140,30),
                ),
              ),
            ),


            const  SizedBox(height: 20,),
            Padding(
              padding: const EdgeInsets.all(0.0),
              child: ElevatedButton(

                onPressed: (){
                  Navigator.push(context,
                    MaterialPageRoute(
                      builder: (context)=>admin_login(),),);
                },
                child:  LocaleText (
                  "AdminA" ,
                  style: GoogleFonts.lato(
                    textStyle: Theme.of(context).textTheme.displayLarge,
                    fontSize: 26,
                    fontWeight: FontWeight.w700,
                    fontStyle: FontStyle.italic,
                  ),
                ),
                style:ElevatedButton.styleFrom(
                  backgroundColor: Colors.white,
                  padding:EdgeInsets.fromLTRB(140,30,140,30),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}