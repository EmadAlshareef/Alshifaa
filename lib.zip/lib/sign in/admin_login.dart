import 'package:awesome_dialog/awesome_dialog.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_locales/flutter_locales.dart';
import 'package:google_fonts/google_fonts.dart';

import '../admin&pharmacstic/aadminHomePage.dart';
import '../screens/asset.dart';
class admin_login extends StatelessWidget {
  final emailController = TextEditingController();
  final passwordController = TextEditingController();
  final formKey = GlobalKey<FormState>();



  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        scrollDirection: Axis.vertical,
        child: Form(
          key: formKey,
          child: Column(
            children: [
              Image.asset('images/rectangle-1.png'),
              const SizedBox(height: 20,),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: TextFormField(
                  controller: emailController,
                  keyboardType: TextInputType.emailAddress,
                  validator: (value) {
                    if (value!.isEmpty) {
                      return 'Email address cannot be empty';
                    }
                    return null;
                  },
                  decoration: InputDecoration(
                    labelText: Localizations.of<Locales>(context, Locales)!.get("AP"),
                    border: OutlineInputBorder(),
                    suffixIcon: Icon(Icons.email),
                  ),
                ),
              ),
              const SizedBox(height: 20,),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 8.0),
                child: TextFormField(
                  controller: passwordController,
                  keyboardType: TextInputType.visiblePassword,
                  obscureText: true,
                  validator: (value) {
                    if (value!.isEmpty) {
                      return 'Password cannot be empty';
                    }
                    return null;
                  },
                  decoration: InputDecoration(
                    labelText: Localizations.of<Locales>(context, Locales)!.get("PASS"),
                    border: OutlineInputBorder(),
                    prefixIcon: Icon(Icons.lock),
                  ),
                ),
              ),
              const SizedBox(height: 20,),
              Container(
                width: double.infinity,
                color: Color.fromARGB(220, 111, 120, 255),
                child: GestureDetector(
                  onTap: () async {
                    if (formKey.currentState!.validate()) {
                      try {
                        DocumentSnapshot adminDoc = await FirebaseFirestore.instance
                            .collection("Admin")
                            .doc("adminLogin")
                            .get();

                        if (adminDoc.exists) {
                          var data = adminDoc.data() as Map<String, dynamic>;
                          if (data["adminEmail"] == emailController.text.trim() && data['adminPassword'] == passwordController.text.trim()) {
                            AwesomeDialog(
                              context: context,
                              dialogType: DialogType.success,
                              animType: AnimType.rightSlide,
                              title: 'Success',
                              desc: 'User is successfully signed in',
                              btnOkOnPress: () {
                                Navigator.push(context,
                                    MaterialPageRoute(
                                        builder: (context)=> HomeScreenadmin()));

                              },
                            ).show();


                          } else {
                            _showErrorDialog(context, 'Invalid email or password.');
                          }
                        } else {
                          _showErrorDialog(context, 'Admin data not found.');
                        }
                      } catch (e) {
                        _showErrorDialog(context, 'An error occurred: $e');
                      }
                    }
                  },
                  child: Text(
                    '                      Admin Log In',
                    style: GoogleFonts.lato(
                      textStyle: Theme.of(context).textTheme.displayLarge,
                      fontSize: 26,
                      fontWeight: FontWeight.w700,
                      fontStyle: FontStyle.italic,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showErrorDialog(BuildContext context, String message) {
    AwesomeDialog(
      context: context,
      dialogType: DialogType.error,
      animType: AnimType.rightSlide,
      title: 'Error',
      desc: message,
      btnOkOnPress: () {},
    ).show();
  }
}