import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:awesome_dialog/awesome_dialog.dart';
import 'package:untitled1/screens/asset.dart';
import 'package:untitled1/sign%20in/user_fire/firease_auth_service.dart';
import 'Reg.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  bool _isSigning = false;
  final firebaseAuthService _auth = firebaseAuthService();
  final FirebaseAuth _firebaseAuth = FirebaseAuth.instance;
  var emailController = TextEditingController();
  var passwordController = TextEditingController();
  var formkey = GlobalKey<FormState>();


  Future _signIN() async {
    setState(() {
      _isSigning = true;
    });

    String email = emailController.text.trim();
    String pass = passwordController.text.trim();

    try {
      User? user = await _auth.signInWithEmailAndPassword(email, pass);
      if (user != null) {
        print("User is successfully signed in");

        AwesomeDialog(
          context: context,
          dialogType: DialogType.success,
          animType: AnimType.rightSlide,
          title: 'Success',
          desc: 'User is successfully signed in',
          btnOkOnPress: () {
            Navigator.push(context,
                MaterialPageRoute(
                    builder: (context)=> HomeScreen()));

          },
        ).show();
      } else {
        throw Exception("User is null");
      }
    } catch (e) {
      AwesomeDialog(
        context: context,
        dialogType: DialogType.error,
        animType: AnimType.rightSlide,
        title: 'Error',
        desc: 'An error occurred:',
        btnOkOnPress: () {},
      ).show();
    } finally {
      setState(() {
        _isSigning = false;
      });
    }
  }


  @override
  void dispose() {
    emailController.dispose();
    passwordController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        scrollDirection: Axis.vertical,
        child: Form(
          key: formkey,
          child: Column(
            children: [
              Image.asset('images/rectangle-1.png'),
              const SizedBox(height: 20,),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: TextFormField(
                  controller: emailController,
                  keyboardType: TextInputType.emailAddress,
                  validator: (value) {
                    if (value!.isEmpty) {
                      return 'Email address cannot be empty';
                    }
                    return null;
                  },
                  decoration: InputDecoration(
                    labelText: 'Email Address & Phone Number',
                    border: OutlineInputBorder(),
                    suffixIcon: Icon(Icons.email,),
                  ),
                ),
              ),
              const SizedBox(height: 20,),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 8.0),
                child: TextFormField(
                  controller: passwordController,
                  keyboardType: TextInputType.visiblePassword,
                  obscureText: true,
                  onFieldSubmitted: (String value) {
                  print(value);
                  },
                  validator: (value) {
                    if (value!.isEmpty) {
                      return 'Password cannot be empty';
                    }
                    return null;
                  },
                  decoration: InputDecoration(
                    labelText: 'Password',
                    border: OutlineInputBorder(),
                    prefixIcon: Icon(Icons.lock,),
                  ),
                ),
              ),
              const SizedBox(height: 20,),
              Padding(
                padding: const EdgeInsets.all(20.0),
                child: Container(
                  width: double.infinity,
                  color: Color.fromARGB(220, 111, 120, 255),
                  child: GestureDetector(
                    onTap: () {
                      if (formkey.currentState!.validate()) {
                        _signIN();
                      }
                    },
                    child: _isSigning
                        ? CircularProgressIndicator(color: Colors.white,)
                        : Text(

                      '                              Log In',
                      style: GoogleFonts.lato(
                        textStyle: Theme.of(context).textTheme.displayLarge,
                        fontSize: 26,
                        fontWeight: FontWeight.w700,
                        fontStyle: FontStyle.italic,
                      ),
                    ),
                  ),
                ),
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text('Don\'t have an account?'),
                  TextButton(
                    onPressed: () {
                      Navigator.push(context,
                        MaterialPageRoute(builder: (context) => Reg(),),);
                    },
                    child: Text(
                      'Register Now',
                      style: TextStyle(color: Colors.green),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }


}