class userModel {

  final String fullname;
  final String email;
  final String phone;
  final String password;


  const userModel({
   required this.fullname,
    required this.email,
    required this.phone,
    required this.password,


});
tojson(){
  return{
    "fullname":fullname,
    "email":email,
    "phone":phone,
    "password":password,


  };
}

}