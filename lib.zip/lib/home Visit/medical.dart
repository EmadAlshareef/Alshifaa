import 'package:flutter/material.dart';
import 'package:flutter_locales/flutter_locales.dart';
import 'package:google_fonts/google_fonts.dart';

import 'HomeVisitDetails/pages/todosHome.dart';

class medicalRecord extends StatefulWidget {
  final List<String> items;
  const medicalRecord({Key? key, required this.items}) : super(key: key);

  @override
  State<StatefulWidget> createState() => _medicalRecordState();
}

class _medicalRecordState extends State<medicalRecord> {
  // this variable holds the selected items
  final List<String> _selectedItems = [];

// This function is triggered when a checkbox is checked or unchecked
  void _itemChange(String itemValue, bool isSelected) {
    setState(() {
      if (isSelected) {
        _selectedItems.add(itemValue);
      } else {
        _selectedItems.remove(itemValue);
      }
    });
  }

  // this function is called when the Cancel button is pressed
  void _cancel() {
    Navigator.pop(context);
  }

// this function is called when the Submit button is tapped
  void _submit() {
    Navigator.pop(context, _selectedItems);
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const LocaleText("select diseases"),
      content: SingleChildScrollView(
        child: ListBody(
          children: widget.items
              .map((item) => CheckboxListTile(
            value: _selectedItems.contains(item),
            title: Text(item),
            controlAffinity: ListTileControlAffinity.leading,
            onChanged: (isChecked) => _itemChange(item, isChecked!),
          ))
              .toList(),
        ),
      ),
      actions: [
        TextButton(
          onPressed: _cancel,
          child: const LocaleText("cancel"),
        ),
        ElevatedButton(
          onPressed: _submit,
          child: const LocaleText("Confirm"),
        ),
      ],
    );
  }
}

// Implement a multi select on the Home screen
class check extends StatefulWidget {
  const check({Key? key}) : super(key: key);

  @override
  State<check> createState() => _checkState();
}

class _checkState extends State<check> {
  List<String> _selectedItems = [];

  void _showMultiSelect() async {
    // a list of selectable items
    // these items can be hard-coded or dynamically fetched from a database/API
    final List<String> items = [
      'diabetes',
      'blood pressure',
      'cancer',
      'Cardiovascular',
      'Disability',
      'Endocrine',
      'Psychological',
      'Neurological'
    ];

    final List<String>? results = await showDialog(
      context: context,
      builder: (BuildContext context) {
        return medicalRecord(items: items);
      },
    );

    // Update UI
    if (results != null) {
      setState(() {
        _selectedItems = results;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: hexStringToColor("5E61F4"),
        centerTitle: true,
        title: const LocaleText("Record",
        style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),
        ),
      ),
      body:Container(
        width: double.infinity,

        decoration: BoxDecoration(
            gradient: LinearGradient(colors: [
              hexStringToColor("5E61F4"),
              hexStringToColor("9546C4"),

            ], begin: Alignment.topCenter, end: Alignment.bottomCenter)),
        child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            // use this button to open the multi-select dialog
            ElevatedButton(
              onPressed: _showMultiSelect,
              child: const Text("select diseases"),
            ),
            const Divider(
              height: 30,
            ),
            // display selected items
            Wrap(
              children: _selectedItems

                  .map((e) => Chip(
                label: Text(e),
              ) ).toList(),
            ),
            SizedBox(height: 400,),

            ElevatedButton(
              onPressed: (){
                    Navigator.push(context, MaterialPageRoute(builder: (context)=>
                        TodosPageHomeVisit()));},
                        child: LocaleText(
                          "Set Home Appointment" ,
                          style: GoogleFonts.robotoCondensed(
                            fontSize: 20,
                            fontWeight: FontWeight.w500,
                            color: Colors.blueAccent,

                          ),
                        ),
                        style:ElevatedButton.styleFrom(
                          backgroundColor: Colors.white,

                        ),
                                   ),
                   ],


        ),
      ),
      ),
    );
  }
}
hexStringToColor(String hexColor) {
  hexColor = hexColor.toUpperCase().replaceAll("#", "");
  if (hexColor.length == 6) {
    hexColor = "FF" + hexColor;
  }
  return Color(int.parse(hexColor, radix: 16));
}