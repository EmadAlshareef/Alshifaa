import 'package:flutter/material.dart';
import 'package:flutter_locales/flutter_locales.dart';
import 'package:google_fonts/google_fonts.dart';

import '../screens/asset.dart';
import 'medical.dart';

class homeVistScreen extends StatelessWidget {
  const homeVistScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(appBar: AppBar(
        backgroundColor: hexStringToColor("5E61F4"),
        elevation: 0,
      title:const  LocaleText( "visit",style: TextStyle(fontSize: 30,fontWeight:FontWeight.bold),),
      centerTitle: true,
        leading: BackButton(
        onPressed:(){
    Navigator.push(context,
    MaterialPageRoute(
    builder: (context)=>HomeScreen(),),);
    },
    ),

    ),
      body: Container(
        width: double.infinity,

        decoration: BoxDecoration(
            gradient: LinearGradient(colors: [
              hexStringToColor("5E61F4"),
              hexStringToColor("9546C4"),

            ], begin: Alignment.topCenter, end: Alignment.bottomCenter)),
        child: Column(
          children: [
            const  SizedBox(height: 30,),
            Padding(
              padding: const EdgeInsets.all(0.0),
              child: ElevatedButton(

                onPressed: (){
                  Navigator.push(context,
                    MaterialPageRoute(
                      builder: (context)=>check (),),);                },
                child: LocaleText(
                  "ge",
                  style: GoogleFonts.robotoCondensed(
                    fontSize: 23,
                    fontWeight: FontWeight.w500,
                    color: Colors.blueAccent,

                  ),
                ),
                style:ElevatedButton.styleFrom(
                  backgroundColor: Colors.white,
                  padding:EdgeInsets.fromLTRB(30,30,30,30),
                ),
              ),
            ),
            const  SizedBox(height: 30,),
            Padding(
              padding: const EdgeInsets.all(0.0),
              child: ElevatedButton(

                onPressed: (){
                  Navigator.push(context,
                    MaterialPageRoute(
                      builder: (context)=>check (),),);                },
                child: LocaleText(
                  "ps",
                  style: GoogleFonts.robotoCondensed(
                    fontSize: 23,
                    fontWeight: FontWeight.w500,
                    color: Colors.blueAccent,

                  ),
                ),
                style:ElevatedButton.styleFrom(
                  backgroundColor: Colors.white,
                  padding:EdgeInsets.fromLTRB(80,30,80,30),
                ),
              ),
            ),
            const  SizedBox(height: 30,),
            Padding(
              padding: const EdgeInsets.all(0.0),
              child: ElevatedButton(

                onPressed: (){
                  Navigator.push(context,
                    MaterialPageRoute(
                      builder: (context)=>check (),),);
                },
                child: LocaleText(
                  "Pe" ,
                  style: GoogleFonts.robotoCondensed(
                    fontSize: 23,
                    fontWeight: FontWeight.w500,
                    color: Colors.blueAccent,

                  ),
                ),
                style:ElevatedButton.styleFrom(
                  backgroundColor: Colors.white,
                  padding:EdgeInsets.fromLTRB(80,30,80,30),
                ),
              ),
            ),
            const  SizedBox(height: 30,),
            Padding(
              padding: const EdgeInsets.all(0.0),
              child: ElevatedButton(

                onPressed: (){
                  Navigator.push(context,
                    MaterialPageRoute(
                      builder: (context)=>check (),),);                },
                child:LocaleText(
                  "ph" ,
                  style: GoogleFonts.robotoCondensed(
                    fontSize: 23,
                    fontWeight: FontWeight.w500,
                    color: Colors.blueAccent,

                  ),
                ),
                style:ElevatedButton.styleFrom(
                  backgroundColor: Colors.white,
                  padding:EdgeInsets.fromLTRB(55,30,55,30),
                ),
              ),
            ),

          ],
        ),
      ),


    );
  }
}
hexStringToColor(String hexColor) {
  hexColor = hexColor.toUpperCase().replaceAll("#", "");
  if (hexColor.length == 6) {
    hexColor = "FF" + hexColor;
  }
  return Color(int.parse(hexColor, radix: 16));
}
