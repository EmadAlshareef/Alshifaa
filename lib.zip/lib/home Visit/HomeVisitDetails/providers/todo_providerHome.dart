import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../models/todoHome.dart';

class TodoProviderHome extends ChangeNotifier {
  String currentDateHome = DateFormat.yMMMd().format(DateTime.now());
  List<String> categoriesHome =
  [""];

  //test data
  List<TodoHomeVisit> allTodos = [
  ];

  List<TodoHomeVisit> get deletedTodos {
    return allTodos.where((element) => element.toBeDeleted).toList();
  }

  List<TodoHomeVisit> get completedTodos {
    return allTodos
        .where((element) => element.isComplete && !element.toBeDeleted)
        .toList();
  }



  void addTodo(String title, String description, String date, String time,
      String category) {
    allTodos.add(TodoHomeVisit(
        title: title,
        date: date,
        description: description,
        time: time,
        category: category));
    notifyListeners();
  }

  void toggleToBeDeleted(TodoHomeVisit todo) {
    todo.toBeDeleted = !todo.toBeDeleted;
    notifyListeners();
  }

  void toggleIsComplete(TodoHomeVisit todo) {
    todo.isComplete = !todo.isComplete;
    notifyListeners();
  }

  List<TodoHomeVisit> getSearchResults(String task) {
    return allTodos
        .where((element) =>
            RegExp(task, caseSensitive: false).hasMatch(element.title))
        .toList();
  }

  void addCategory(double category) {
    categoriesHome.add(category as String);
    notifyListeners();
  }

  void removeCategory(String category) {
    categoriesHome.remove(category);
    notifyListeners();
  }
}
