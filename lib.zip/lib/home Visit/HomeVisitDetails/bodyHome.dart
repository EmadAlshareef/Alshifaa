import 'package:flutter/material.dart';
import 'package:flutter_locales/flutter_locales.dart';
import 'package:untitled1/home%20Visit/HomeVisitDetails/pages/todosHome.dart';


class BodyHomeVisit extends StatelessWidget {
  const BodyHomeVisit({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(

        title:  Padding(
          padding: EdgeInsets.only(top: 15, bottom: 10),
          child: LocaleText(
            "pick home" ,
            style: TextStyle(
                fontWeight: FontWeight.bold, fontSize: 30, color: Colors.black),
          ),
        ),

        bottom: TabBar(
          indicatorColor: Theme.of(context).primaryColor,
          tabs: const [
            Tab(
              text: "Maked appointment",
            ),

          ],
        ),

      ),
      body:

              const TabBarView(
                  children: [TodosPageHomeVisit(),]
              ),

    );
  }
}
