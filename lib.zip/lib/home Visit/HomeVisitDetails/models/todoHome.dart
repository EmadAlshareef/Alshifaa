class TodoHomeVisit {
  String category = "";
  String description = "";
  String title;
  String date;
  String time;
  bool isComplete = false;
  bool toBeDeleted = false;

  TodoHomeVisit(
      {
      required this.title,
      required this.date,
      required this.description,
      required this.time,
      required this.category});
}
