import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:line_icons/line_icons.dart';
import 'package:provider/provider.dart';

import '../models/todoHome.dart';
import '../pages/todoHome.dart';
import '../providers/todo_providerHome.dart';

class TodoTileHomeVisit extends StatefulWidget {
  final TodoHomeVisit todoHomeVisit;
  const TodoTileHomeVisit({super.key, required this.todoHomeVisit});

  @override
  State<TodoTileHomeVisit> createState() => _TodoTileHomeVisitState();
}

class _TodoTileHomeVisitState extends State<TodoTileHomeVisit> {
  @override
  Widget build(BuildContext context) {
    final provider = Provider.of<TodoProviderHome>(context);
    final todo = widget.todoHomeVisit;

    return SizedBox(
      height: 170,
      child: Card(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        elevation: 2,
        child: Padding(
          padding: const EdgeInsets.all(10),
          child: Row(crossAxisAlignment: CrossAxisAlignment.start,
              children: [
            InkWell(
              onTap: () => provider.toggleIsComplete(todo),
              child: Icon(
                todo.isComplete ? LineIcons.checkCircle : LineIcons.circle,
                size: 25,
              ),
            ),
            const Padding(padding: EdgeInsets.only(right: 20)),
            Expanded(
              child: InkWell(
                onTap: () => Navigator.of(context).push(
                  MaterialPageRoute(builder: (context) => TodoPageHomeVisit(todo: todo)),
                ),
                child: Column(


                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Padding(
                              padding: const EdgeInsets.only( bottom: 10),
                              child: Text(
                                todo.title,
                                style: const TextStyle(
                                    fontWeight: FontWeight.bold, fontSize: 20),
                              ),
                            ),
                            SizedBox(width: 10,),
                            InkWell(
                              onTap: () => provider.toggleToBeDeleted(todo),
                              child: todo.toBeDeleted
                                  ? const Text("restore")
                                  : const Text(""),
                            ),
                          ],
                        ),
                        SingleChildScrollView(
                          scrollDirection: Axis.vertical,
                          child:  Column(children: [
                              Visibility(
                                visible: todo.date != provider.currentDateHome,
                                child:Text(
                                    widget.todoHomeVisit.date
                                            .contains(DateTime.now().year.toString())
                                        ? todo.date.replaceAll(
                                            RegExp(", ${DateTime.now().year}"),
                                            todo.time.isNotEmpty ? ", " : "")
                                        : todo.date,
                                    style: const TextStyle(
                                      fontSize: 16,
                                    ),
                                  ),
                                ),

                              Padding(
                                padding: const EdgeInsets.only(bottom: 8.0),
                                child: Text(
                                  todo.time,
                                  style: const TextStyle(
                                    fontSize: 16,
                                  ),
                                ),
                              ),
                            Padding(
                              padding: const EdgeInsets.only(bottom: 8.0),
                              child: Text(
                                todo.date,
                                style: const TextStyle(
                                  fontSize: 16,
                                ),
                              ),
                            ),
                              Text(
                                todo.category,
                                style: const TextStyle(fontSize: 12, color: Colors.grey),
                              ),

                            ]),
                          ),

                      ]),
                ),

            ),





              ],
            )
          ,
        ),
      ),
    );
  }
}
