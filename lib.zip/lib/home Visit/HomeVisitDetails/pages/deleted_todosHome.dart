import 'package:flutter/material.dart';
import 'package:flutter_locales/flutter_locales.dart';
import 'package:provider/provider.dart';
import '../components/todo_tileHome.dart';
import '../models/todoHome.dart';
import '../providers/todo_providerHome.dart';

class DeletedTodosPageHomeVisit extends StatelessWidget {
  const DeletedTodosPageHomeVisit({super.key});

  @override
  Widget build(BuildContext context) {
    final provider = Provider.of<TodoProviderHome>(context);
    final List<TodoHomeVisit> deletedTodos = provider.deletedTodos;

    return Visibility(
      replacement:
          const Center(child: LocaleText("not deleted app")),
      visible: deletedTodos.isNotEmpty,
      child: Padding(
        padding: const EdgeInsets.all(30),
        child: Column(children: [
          Expanded(
            child: ListView.builder(
              itemCount: deletedTodos.length,
              itemBuilder: (context, index) => TodoTileHomeVisit(
                todoHomeVisit: deletedTodos[index],
              ),
            ),
          ),
        ]),
      ),
    );
  }
}
