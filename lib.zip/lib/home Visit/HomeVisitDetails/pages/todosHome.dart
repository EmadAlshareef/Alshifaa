import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:flutter_locales/flutter_locales.dart';
import 'package:line_icons/line_icons.dart';
import 'package:provider/provider.dart';
import '../../../Booked Appointment/clinics.dart';
import '../components/add_todo_modal_bottom_sheetHome.dart';
import '../components/todo_tileHome.dart';
import '../providers/todo_providerHome.dart';



class TodosPageHomeVisit extends StatelessWidget {
  const TodosPageHomeVisit({super.key});



  @override
  Widget build(BuildContext context) {
    Color primaryColor = Theme.of(context).primaryColor;
    final provider = Provider.of<TodoProviderHome>(context);
    var todosHomeVisit = provider.allTodos;

    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        backgroundColor:hexStringToColor("5E61F4"),
        centerTitle: true,
        title: LocaleText("visit",style: TextStyle(
          fontSize: 24,
          fontWeight: FontWeight.bold,
        ),),
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor:hexStringToColor("5E61F4"),
        onPressed: () => showModalBottomSheet(
          context: context,
          builder: (BuildContext context) =>
             const Wrap(children:  [AddTaskModalBottomSheetHomeVisit()]),
        ),
        child: const Icon(
          LineIcons.plus,
        ),
      ),
      body:Container(
        width: double.infinity,

        decoration: BoxDecoration(
            gradient: LinearGradient(colors: [
              hexStringToColor("5E61F4"),
              hexStringToColor("9546C4"),

            ], begin: Alignment.topCenter, end: Alignment.bottomCenter)),
        child: Padding(
        padding: const EdgeInsets.all(30),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Expanded(
            child: Padding(
              padding: const EdgeInsets.only(top:0),
              child: Visibility(
                visible: todosHomeVisit.isNotEmpty,
                replacement: const Center(
                  child: LocaleText("plus home appointment ", style:
                  TextStyle( fontSize: 26,
                      fontWeight:FontWeight.bold,
                      letterSpacing: 0.1),
                  ),
                ),
                child: SingleChildScrollView(
                  physics: BouncingScrollPhysics(),
                  child: ListView.builder(
                      shrinkWrap: true,
                      itemCount: todosHomeVisit.length,
                      itemBuilder: (context, index) =>
                          TodoTileHomeVisit(todoHomeVisit: todosHomeVisit[index])),
                ),
              ),
            ),
          ),

        ]),
      ),
      ),
    );
  }
}