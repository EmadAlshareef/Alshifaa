import 'package:flutter/material.dart';
import 'package:flutter_locales/flutter_locales.dart';
import 'package:provider/provider.dart';
import 'package:untitled1/home%20Visit/HomeVisitDetails/components/todo_tileHome.dart';
import 'package:untitled1/home%20Visit/HomeVisitDetails/models/todoHome.dart';
import 'package:untitled1/home%20Visit/HomeVisitDetails/providers/todo_providerHome.dart';

import '../../../admin&pharmacstic/aadminHomePage.dart';


class CompletedTodosPageHome extends StatelessWidget {
  const CompletedTodosPageHome({super.key});

  @override
  Widget build(BuildContext context) {
    final provider = Provider.of<TodoProviderHome>(context);
    final List<TodoHomeVisit> completedTodos = provider.completedTodos;

    return Scaffold(
        appBar: AppBar(
          backgroundColor: hexStringToColor("5E61F4"),
          centerTitle: true,
          title: LocaleText("confirm home",style: TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 26,

          ),),
        ),

           body:Container(
               width: double.infinity,

               decoration: BoxDecoration(
                   gradient: LinearGradient(colors: [
                     hexStringToColor("5E61F4"),
                     hexStringToColor("9546C4"),

                   ], begin: Alignment.topCenter, end: Alignment.bottomCenter)),
               child: Visibility(
      replacement: const Center(
        child: LocaleText("no home app",style: TextStyle(
          fontWeight: FontWeight.bold,
          fontSize: 20,
        ),),
      ),
      visible: completedTodos.isNotEmpty,
      child: Padding(
        padding: const EdgeInsets.all(30),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text("${completedTodos.length} Confirmed"),
          const Divider(),
          const Padding(padding: EdgeInsets.only(bottom: 10)),
          Expanded(
            child: ListView.builder(
              itemCount: completedTodos.length,
              itemBuilder: (context, index) => TodoTileHomeVisit(
                todoHomeVisit: completedTodos[index],
              ),
            ),
          ),
        ]),
      ),
    )
  )
);
}
}
