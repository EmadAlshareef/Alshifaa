import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter_locales/flutter_locales.dart';
import 'package:google_fonts/google_fonts.dart';

import '../Booked Appointment/locations.dart';
import '../home Visit/HomeVisitDetails/pages/completed_todosHome.dart';
import '../home Visit/home_Visit.dart';
import '../models/models.dart';
import '../pharmc/screens/home/home_screen.dart';
import '../settings/settings.dart';
import 'details.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  late PageController _pageController;
  int _currentPage = 0;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _pageController =
        PageController(initialPage: _currentPage, viewportFraction: 0.8);
  }

  @override
  void dispose() {
    // TODO: implement dispose
    super.dispose();
    _pageController.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(appBar: AppBar(
      backgroundColor: hexStringToColor("5E61F4"),
      elevation: 0,
      centerTitle: true,
      title: LocaleText("alshfaa",
        style: TextStyle(
          fontWeight: FontWeight.bold,
        ),
      ),

      actions: [IconButton(onPressed: (){

        Navigator.push(context,
          MaterialPageRoute(
            builder: (context)=>settings(),),
        );
      }, icon: Icon(Icons.menu),)],

    ),

        body:
        SingleChildScrollView(
          scrollDirection: Axis.vertical,
          child: Container(
            width: double.infinity,

            decoration: BoxDecoration(
                gradient: LinearGradient(colors: [
                  hexStringToColor("5E61F4"),
                  hexStringToColor("9546C4"),

                ], begin: Alignment.topCenter, end: Alignment.bottomCenter)),
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 10),
              child: Column(
                children: <Widget>[
                  const Padding(
                    padding: EdgeInsets.symmetric(vertical: 12),
                    child: Center(
                      child:LocaleText("posters",
                          style: TextStyle(
                              fontWeight: FontWeight.bold,
                              color: Colors.black87,
                              fontSize: 30)),
                    ),
                  ),
                  AspectRatio(
                    aspectRatio: 0.85,
                    child: PageView.builder(
                        itemCount: dataList.length,
                        physics: const ClampingScrollPhysics(),
                        controller: _pageController,
                        itemBuilder: (context, index) {
                          return carouselView(index);
                        }),
                  ),
                  SingleChildScrollView(
                    scrollDirection: Axis.vertical,
                    child: Column(
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.center,


                            children: [
                              SingleChildScrollView(
                                scrollDirection:Axis.horizontal,

                                child: Row(
                                  children: [
                                    Column(
                                      children: [

                                        Padding(
                                          padding: const EdgeInsets.all(1.0),
                                          child: ElevatedButton(
                                            onPressed: (){
                                                Navigator.push(context,
                                                  MaterialPageRoute(
                                                    builder: (context)=>homeVistScreen(),),);
                                            },
                                            child:Container(
                                              width: 60,
                                              height: 80,
                                              child: SingleChildScrollView(
                                                scrollDirection: Axis.vertical,
                                                child: Column(
                                                  children: [ Container(
                                                    width: 40,
                                                    height: 40,
                                                    child:  Image.asset('images/home.png'),),
                                                    LocaleText(
                                                      "visit",
                                                      style:

                                                      GoogleFonts.robotoCondensed(
                                                        fontSize: 12,
                                                        fontWeight: FontWeight.w500,
                                                        color: Colors.blueAccent,

                                                      ),
                                                    ),


                                                  ],),
                                              ),),
                                            //
                                            //
                                            style:ElevatedButton.styleFrom(
                                              backgroundColor: Colors.white,
                                              padding:EdgeInsets.fromLTRB(40,20,40,20),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                    SizedBox(width: 20,),

                                  ],
                                ),
                              ),

                              const  SizedBox(height: 20,),
                              SingleChildScrollView(
                                scrollDirection:Axis.horizontal,
                                child: Row(
                                  children: [
                                    Column(
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      children: [
                                        // Image.asset('images/app.png'),
                                        Padding(
                                          padding: const EdgeInsets.all(1.0),
                                          child: ElevatedButton(
                                            onPressed: (){
                                              Navigator.push(context,
                                                MaterialPageRoute(
                                                  builder: (context)=>pharmacyScreen(),),);
                                            },
                                            child:Container(
                                              width: 60,
                                              height: 80,
                                              child: SingleChildScrollView(
                                                scrollDirection: Axis.vertical,
                                                child: Column(
                                                  children: [ Container(
                                                    width: 40,
                                                    height: 40,
                                                    child:  Image.asset('images/pharmacy.png'),),
                                                    LocaleText(
                                                      "pharmacy",
                                                      style:

                                                      GoogleFonts.robotoCondensed(
                                                        fontSize: 10,
                                                        fontWeight: FontWeight.w500,
                                                        color: Colors.blueAccent,

                                                      ),
                                                    ),


                                                  ],),
                                              ),),
                                            //
                                            //
                                            style:ElevatedButton.styleFrom(
                                              backgroundColor: Colors.white,
                                              padding:EdgeInsets.fromLTRB(40,20,40,20),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                    SizedBox(width: 20,),

                                  ],
                                ),
                              ),
                            ],
                          ),
                          SizedBox(height: 20,),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              SingleChildScrollView(
                                scrollDirection:Axis.horizontal,

                                child: Row(
                                  children: [
                                    Column(
                                      children: [
                                        // Image.asset('images/app.png'),
                                        Padding(
                                          padding: const EdgeInsets.all(1.0),
                                          child: ElevatedButton(
                                            onPressed: (){
                                                Navigator.push(context,
                                                  MaterialPageRoute(
                                                    builder: (context)=>CompletedTodosPageHome(),),);
                                            },
                                            child:Container(
                                              width: 60,
                                              height: 80,
                                              child: SingleChildScrollView(
                                                scrollDirection: Axis.vertical,
                                                child: Column(
                                                  children: [ Container(
                                                    width: 40,
                                                    height: 40,
                                                    child:  Image.asset('images/Booked.png'),),
                                                    LocaleText(
                                                      "MYapp",
                                                      style:

                                                      GoogleFonts.robotoCondensed(
                                                        fontSize: 12,
                                                        fontWeight: FontWeight.w500,
                                                        color: Colors.blueAccent,

                                                      ),
                                                    ),


                                                  ],),
                                              ),),
                                            //
                                            //
                                            style:ElevatedButton.styleFrom(
                                              backgroundColor: Colors.white,
                                              padding:EdgeInsets.fromLTRB(40,20,40,20),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                    SizedBox(width: 20,),

                                  ],
                                ),
                              ),

                              const  SizedBox(height: 20,),
                              SingleChildScrollView(
                                scrollDirection:Axis.horizontal,
                                child: Row(
                                  children: [
                                    Column(
                                      children: [
                                        // Image.asset('images/app.png'),
                                        Padding(
                                          padding: const EdgeInsets.all(1.0),
                                          child: ElevatedButton(
                                            onPressed: (){
                                              Navigator.push(context,
                                                MaterialPageRoute(
                                                  builder: (context)=>locations(),),);
                                            },
                                            child:Container(
                                              width: 60,
                                              height: 80,
                                              child: SingleChildScrollView(
                                                scrollDirection: Axis.vertical,
                                                child: Column(
                                                  children: [ Container(
                                                    width: 40,
                                                    height: 40,
                                                    child: Image.asset('images/app.png'),),
                                                    LocaleText(
                                                      "bookA",
                                                      style:

                                                      GoogleFonts.robotoCondensed(
                                                        fontSize: 12,
                                                        fontWeight: FontWeight.w500,
                                                        color: Colors.blueAccent,

                                                      ),
                                                    ),


                                                  ],),
                                              ),),
                                            //
                                            //
                                            style:ElevatedButton.styleFrom(
                                              backgroundColor: Colors.white,
                                              padding:EdgeInsets.fromLTRB(40,20,40,20),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),

                                  ],
                                ),
                              ),
                            ],
                          ),



                        ]
                    ),
                  ),
                ],
              ),
            ),
          ),
        )
    );
  }

  Widget carouselView(int index) {
    return AnimatedBuilder(
      animation: _pageController,
      builder: (context, child) {
        double value = 0.0;
        if (_pageController.position.haveDimensions) {
          value = index.toDouble() - (_pageController.page ?? 0);
          value = (value * 0.038).clamp(-1, 1);
          ;
        }
        return Transform.rotate(
          angle: pi * value,
          child: carouselCard(dataList[index]),
        );
      },
    );
  }

  Widget carouselCard(DataModel data) {
    return Column(
      children: <Widget>[
        Expanded(
          child: Padding(
            padding: const EdgeInsets.all(10.0),
            child: Hero(
              tag: data.imageName,
              child: GestureDetector(
                onTap: () {
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => DetailsScreen(data: data)));
                },
                child: Container(
                  decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(30),
                      image: DecorationImage(
                          image: AssetImage(
                            data.imageName,
                          ),
                          fit: BoxFit.fill),
                      boxShadow: const [
                        BoxShadow(
                            offset: Offset(0, 4),
                            blurRadius: 4,
                            color: Colors.black26)
                      ]),
                ),
              ),
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(vertical:  10),
          child: Text(
            data.title,
            style: const TextStyle(
                color: Colors.black45,
                fontSize: 25,
                fontWeight: FontWeight.bold),
          ),
        ),

      ],
    );
  }
}

hexStringToColor(String hexColor) {
  hexColor = hexColor.toUpperCase().replaceAll("#", "");
  if (hexColor.length == 6) {
    hexColor = "FF" + hexColor;
  }
  return Color(int.parse(hexColor, radix: 16));
}