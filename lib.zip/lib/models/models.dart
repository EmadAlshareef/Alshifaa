class DataModel {
  final String title;
  final String imageName;
  final double price;
  DataModel(
      this.title,
      this.imageName,
      this.price,
      );
}

List<DataModel> dataList = [
  DataModel("Psychiatric Diseases", "images/alshifaa.jpg", 300.8),
  DataModel("Blood Donor", "images/alhifaa3.jpg", 245.2),
  DataModel("Prevention", "images/alshifaa2.jpg", 168.2),
  DataModel("Pediatrics", "images/poster.png", 136.7),
];