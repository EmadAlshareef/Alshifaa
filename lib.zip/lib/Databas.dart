
import 'package:cloud_firestore/cloud_firestore.dart';

class DatabaseMethod{
  Future addAppointmentDetails(Map<String ,dynamic> appointmentDetailsMap, String id) async{

    return await FirebaseFirestore.instance.collection("Appointment").doc(id).set(appointmentDetailsMap);
  }

  Future<void> addLoction(Map<String ,dynamic> addLocationdetails, String uid) async {
    return await FirebaseFirestore.instance.collection("Locations").doc(uid).set(
        addLocationdetails
    );
  }





}