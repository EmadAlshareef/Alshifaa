import 'dart:typed_data';
import 'dart:ui' as ui;
import 'package:custom_info_window/custom_info_window.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';


import 'package:google_maps_flutter/google_maps_flutter.dart';

import '../Booked Appointment/clinics.dart';





class CustomMarkerInfoIrbed extends StatefulWidget {
  const CustomMarkerInfoIrbed({Key? key}) : super(key: key);

  @override
  _CustomMarkerInfoIrbedState createState() => _CustomMarkerInfoIrbedState();
}

class _CustomMarkerInfoIrbedState extends State<CustomMarkerInfoIrbed> {

  CustomInfoWindowController _customInfoWindowController =
  CustomInfoWindowController();
  final LatLng _latLng = LatLng(32.537460, 35.8444403);
  final double _zoom = 15.0;
  Set<Marker> _markers = {};
  List<String> images = [ 'images/baby_vector_free_icon_.png' , 'images/marker.png' ,];
  Uint8List? markerImage;

  Future<Uint8List> getBytesFromAsset(String path, int width) async {
    ByteData data = await rootBundle.load(path);
    ui.Codec codec = await ui.instantiateImageCodec(data.buffer.asUint8List(), targetWidth: width);
    ui.FrameInfo fi = await codec.getNextFrame();
    return (await fi.image.toByteData(format: ui.ImageByteFormat.png))!.buffer.asUint8List();

  }

  @override
  void dispose() {
    _customInfoWindowController.dispose();
    super.dispose();
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    loadData() ;

  }
  //Set<Marker> _markers = {};
  loadData()async{

    for(int i = 0 ; i < images.length ; i++){
      print('name'+images[i].toString());
      final Uint8List markerIcon = await getBytesFromAsset(images[i].toString(), 100);

      if(i == 1 ){
        _markers.add(Marker(
            markerId: MarkerId('2'),
            position: LatLng(32.537460, 35.8444403),
            icon: BitmapDescriptor.fromBytes(markerIcon),
            onTap: () {
              _customInfoWindowController.addInfoWindow!(
                Column(
                  children: [
                    Expanded(
                      child: Container(
                        decoration: BoxDecoration(
                          color: Colors.blue,
                          borderRadius: BorderRadius.circular(4),
                        ),
                        child: Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(
                                Icons.account_circle,
                                color: Colors.white,
                                size: 30,
                              ),
                              SizedBox(
                                width: 8.0,
                              ),
                              Text(
                                "I am here",
                                style:
                                Theme.of(context).textTheme.titleLarge!.copyWith(
                                  color: Colors.white,
                                ),
                              )
                            ],
                          ),
                        ),
                        width: double.infinity,
                        height: double.infinity,
                      ),
                    ),
                    // Triangle.isosceles(
                    //   edge: Edge.BOTTOM,
                    //   child: Container(
                    //     color: Colors.blue,
                    //     width: 20.0,
                    //     height: 10.0,
                    //   ),
                    // ),
                  ],
                ),
                LatLng(32.537460, 35.8444403),
              );
            }
        ));
      }else {
        _markers.add( Marker(
            markerId: MarkerId(i.toString()),
            position: LatLng(32.537460, 35.8444403),
            icon: BitmapDescriptor.fromBytes(markerIcon),
            onTap: () {
              _customInfoWindowController.addInfoWindow!(
                Container(
                  width: 300,
                  height: 200,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    border: Border.all(color: Colors.grey),
                    borderRadius: BorderRadius.circular(10.0),
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children:  [
                      Container(
                        width: 300,
                        height: 100,
                        decoration: const BoxDecoration(
                          image:  DecorationImage(
                              image: NetworkImage('https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTZI33VaYBTGR9FnKa90sxc4UByZu5lkUsmGA&s'),
                              fit: BoxFit.fitWidth,
                              filterQuality: FilterQuality.high),
                          borderRadius:  BorderRadius.all(
                            Radius.circular(10.0),
                          ),
                          color: Colors.red,
                        ),
                      ),
                      const   Padding(
                        padding:  EdgeInsets.only(top: 10 , left: 10 , right: 10),
                        child: Row(
                          children: [
                            SizedBox(
                              width: 100,
                              child: Text(
                                'Al Shifaa Clinic',
                                maxLines: 1,
                                overflow: TextOverflow.fade,
                                softWrap: false,
                                style: TextStyle(color: Colors.black),
                              ),
                            ),
                            Spacer(),
                            Text(
                              'Ir-bed',
                              style: TextStyle(color: Colors.black),

                            )
                          ],
                        ),
                      ),//text
                      const  Padding(
                        padding:  EdgeInsets.only(top: 10 , left: 10 , right: 10),
                        child: Text(
                          'Her is the location of our branch in Ir-bed',
                          maxLines: 2,
                          style: TextStyle(color: Colors.black),

                        ),
                      ),

                    ],
                  ),
                ),
                LatLng(32.537460, 35.8444403),
              );
            }
        ));
      }

      setState(() {

      });
    }

  }

  @override
  Widget build(BuildContext context) {
    // loadData() ;
    return Scaffold(
      appBar: AppBar(
        title: Text('Custom Info Window In Ir-bed'),
        backgroundColor: Colors.blue,
      ),
      body: Stack(
        children: <Widget>[
          GoogleMap(
            onTap: (position) {
              _customInfoWindowController.hideInfoWindow!();
            },
            onCameraMove: (position) {
              _customInfoWindowController.onCameraMove!();
            },
            onMapCreated: (GoogleMapController controller) async {
              _customInfoWindowController.googleMapController = controller;
            },
            markers: _markers,
            initialCameraPosition: CameraPosition(
              target: _latLng,
              zoom: _zoom,
            ),
          ),
          CustomInfoWindow(
            controller: _customInfoWindowController,
            height: 200,
            width: 300,
            offset: 35,
          ),
          Column(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              Container(

                width: double.infinity,
                color: Color.fromARGB(220, 111, 120, 255),
                child:MaterialButton(
                  onPressed: (){

                    Navigator.push(context,
                      MaterialPageRoute(
                        builder: (context)=>bookapp(),),);},

                  child: Text(
                      'Complete Appointment',
                      style: GoogleFonts.robotoCondensed(
                        fontSize: 20,
                        fontWeight: FontWeight.w500,
                        color: Colors.white,
                      )
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}