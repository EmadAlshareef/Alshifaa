
import 'package:flutter/material.dart';
import 'package:flutter_locales/flutter_locales.dart';
import 'package:google_fonts/google_fonts.dart';
import '../Booked Appointment/Bookeddddd/app/app.dart';
import '../home Visit/HomeVisitDetails/pages/completed_todosHome.dart';
import '../pharmc/screens/home/home_screen.dart';
import '../settings/FeedBackDetails/pages/completed_todosFeedback.dart';

class HomeScreenadmin extends StatefulWidget {
  const HomeScreenadmin({Key? key}) : super(key: key);

  @override
  _HomeScreenadminState createState() => _HomeScreenadminState();
}

class _HomeScreenadminState extends State<HomeScreenadmin> {




  @override
  Widget build(BuildContext context) {
    return Scaffold(appBar: AppBar(
      backgroundColor: hexStringToColor("5E61F4"),
      elevation: 0,
      centerTitle: true,
      title: LocaleText("alshfaa",
        style: TextStyle(
          fontWeight: FontWeight.bold,
        ),
      ),
    ),
      body:
      Container(width: double.infinity,

          decoration: BoxDecoration(
              gradient: LinearGradient(colors: [
                hexStringToColor("5E61F4"),
                hexStringToColor("9546C4"),

              ], begin: Alignment.topCenter, end: Alignment.bottomCenter)),
          child:
                 Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children:[

                    SingleChildScrollView(
                      scrollDirection: Axis.vertical,
                      child: Column(
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              crossAxisAlignment: CrossAxisAlignment.center,


                              children: [
                                SingleChildScrollView(
                                  scrollDirection: Axis.horizontal,

                                  child: Row(
                                    children: [
                                      Column(
                                        children: [

                                          Padding(
                                            padding: const EdgeInsets.all(1.0),
                                            child: ElevatedButton(
                                              onPressed: () {
                                                Navigator.push(context,
                                                  MaterialPageRoute(
                                                    builder: (context) =>
                                                        CompletedTodosPageHome(),),);
                                              },
                                              child: Container(
                                                width: 60,
                                                height: 80,
                                                child: SingleChildScrollView(
                                                  scrollDirection: Axis.vertical,
                                                  child: Column(
                                                    children: [ Container(
                                                      width: 40,
                                                      height: 40,
                                                      child: Image.asset(
                                                          'images/home.png'),),
                                                      LocaleText(
                                                        "visit",
                                                        style:

                                                        GoogleFonts
                                                            .robotoCondensed(
                                                          fontSize: 12,
                                                          fontWeight: FontWeight
                                                              .w500,
                                                          color: Colors
                                                              .blueAccent,

                                                        ),
                                                      ),


                                                    ],),
                                                ),),
                                              //
                                              //
                                              style: ElevatedButton.styleFrom(
                                                backgroundColor: Colors.white,
                                                padding: EdgeInsets.fromLTRB(
                                                    40, 20, 40, 20),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                      SizedBox(width: 20,),

                                    ],
                                  ),
                                ),

                                const SizedBox(height: 20,),
                                SingleChildScrollView(
                                  scrollDirection: Axis.horizontal,
                                  child: Row(
                                    children: [
                                      Column(
                                        mainAxisAlignment: MainAxisAlignment
                                            .center,
                                        crossAxisAlignment: CrossAxisAlignment
                                            .center,
                                        children: [
                                          // Image.asset('images/app.png'),
                                          Padding(
                                            padding: const EdgeInsets.all(1.0),
                                            child: ElevatedButton(
                                              onPressed: () {
                                                Navigator.push(context,
                                                  MaterialPageRoute(
                                                    builder: (context) =>
                                                        pharmacyScreen(),),);
                                              },
                                              child: Container(
                                                width: 60,
                                                height: 80,
                                                child: SingleChildScrollView(
                                                  scrollDirection: Axis.vertical,
                                                  child: Column(
                                                    children: [ Container(
                                                      width: 40,
                                                      height: 40,
                                                      child: Image.asset(
                                                          'images/pharmacy.png'),),
                                                      LocaleText(
                                                        "pharmacy",
                                                        style:

                                                        GoogleFonts
                                                            .robotoCondensed(
                                                          fontSize: 10,
                                                          fontWeight: FontWeight
                                                              .w500,
                                                          color: Colors
                                                              .blueAccent,

                                                        ),
                                                      ),


                                                    ],),
                                                ),),
                                              //
                                              //
                                              style: ElevatedButton.styleFrom(
                                                backgroundColor: Colors.white,
                                                padding: EdgeInsets.fromLTRB(
                                                    40, 20, 40, 20),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                      SizedBox(width: 20,),

                                    ],
                                  ),
                                ),
                              ],
                            ),
                            SizedBox(height: 20,),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                SingleChildScrollView(
                                  scrollDirection: Axis.horizontal,

                                  child: Row(
                                    children: [
                                      Column(
                                        children: [
                                          // Image.asset('images/app.png'),
                                          Padding(
                                            padding: const EdgeInsets.all(1.0),
                                            child: ElevatedButton(
                                              onPressed: () {
                                                Navigator.push(context,
                                                  MaterialPageRoute(
                                                    builder: (context) =>
                                                        CompletedTodosPageFeedBack(),),);
                                              },
                                              child: Container(
                                                width: 60,
                                                height: 80,
                                                child: SingleChildScrollView(
                                                  scrollDirection: Axis.vertical,
                                                  child: Column(
                                                    children: [ Container(
                                                      width: 40,
                                                      height: 40,
                                                      child: Image.asset(
                                                          'images/Booked.png'),),
                                                      Text(
                                                        "FeedBack",
                                                        style:
                                                        GoogleFonts
                                                            .robotoCondensed(
                                                          fontSize: 12,
                                                          fontWeight: FontWeight
                                                              .w500,
                                                          color: Colors
                                                              .blueAccent,

                                                        ),
                                                      ),


                                                    ],),
                                                ),),
                                              //
                                              //
                                              style: ElevatedButton.styleFrom(
                                                backgroundColor: Colors.white,
                                                padding: EdgeInsets.fromLTRB(
                                                    40, 20, 40, 20),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                      SizedBox(width: 20,),

                                    ],
                                  ),
                                ),

                                const SizedBox(height: 20,),
                                SingleChildScrollView(
                                  scrollDirection: Axis.horizontal,
                                  child: Row(
                                    children: [
                                      Column(
                                        children: [
                                          // Image.asset('images/app.png'),
                                          Padding(
                                            padding: const EdgeInsets.all(1.0),
                                            child: ElevatedButton(
                                              onPressed: () {
                                                Navigator.push(context,
                                                  MaterialPageRoute(
                                                    builder: (context) =>
                                                        rrr(),),);
                                              },
                                              child: Container(
                                                width: 60,
                                                height: 80,
                                                child: SingleChildScrollView(
                                                  scrollDirection: Axis.vertical,
                                                  child: Column(
                                                    children: [ Container(
                                                      width: 40,
                                                      height: 40,
                                                      child: Image.asset(
                                                          'images/app.png'),),
                                                      LocaleText(
                                                        "bookA",
                                                        style:

                                                        GoogleFonts
                                                            .robotoCondensed(
                                                          fontSize: 12,
                                                          fontWeight: FontWeight
                                                              .w500,
                                                          color: Colors
                                                              .blueAccent,

                                                        ),
                                                      ),


                                                    ],),
                                                ),),
                                              //
                                              //
                                              style: ElevatedButton.styleFrom(
                                                backgroundColor: Colors.white,
                                                padding: EdgeInsets.fromLTRB(
                                                    40, 20, 40, 20),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),

                                    ],
                                  ),
                                ),
                              ],
                            ),


                          ]
                      ),
                    ),
                  ],
                ),

            ),


    );
  }


}
hexStringToColor(String hexColor) {
  hexColor = hexColor.toUpperCase().replaceAll("#", "");
  if (hexColor.length == 6) {
    hexColor = "FF" + hexColor;
  }
  return Color(int.parse(hexColor, radix: 16));
}