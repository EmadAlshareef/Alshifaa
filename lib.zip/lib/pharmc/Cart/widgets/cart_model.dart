import 'package:hive/hive.dart';

/// Represents an item in the shopping cart with persistent storage capabilities.
///
/// This class is annotated with Hive type and fields annotations for serialization.
@HiveType(typeId: 0)
class PersistentShoppingCartItem {
  /// The unique identifier for the product.
  @HiveField(0)
  final String productId;

  /// The name of the product.
  @HiveField(1)
  final String productName;

  /// The optional description of the product.
  @HiveField(2)
  final String? productDescription;

  /// The optional thumbnail image URL for the product.
  @HiveField(3)
  final String? productThumbnail;

  /// The optional list of image URLs for the product.
  @HiveField(4)
  final List<String>? productImages;

  /// The unit price of the product.
  @HiveField(5)
  final double unitPrice;

  /// The quantity of the product in the shopping cart.
  @HiveField(6)
  int quantity;

  /// The optional details of the product.
  @HiveField(7)
  final Map<String, dynamic>? productDetails;

  /// Getter for the key, using the [productId] as the key.
  @HiveField(8)
  String get key => productId;

  /// Creates a [PersistentShoppingCartItem] instance.
  ///
  /// The [productId], [productName], [unitPrice], and [quantity] are required.
  PersistentShoppingCartItem({
    required this.productId,
    required this.productName,
    this.productThumbnail,
    this.productDescription,
    this.productImages,
    required this.unitPrice,
    required this.quantity,
    this.productDetails,
  });

  /// Converts the [PersistentShoppingCartItem] instance to a Map.
  ///
  /// This method is used for serialization.
  Map<String, dynamic> toJson() {
    return {
      'productId': productId,
      'productName': productName,
      'productDescription': productDescription,
      'productThumbnail': productThumbnail,
      'productImages': productImages,
      'unitPrice': unitPrice,
      'quantity': quantity,
      'productDetails': productDetails,
    };
  }

  /// Calculates the total price for this item.
  double get totalPrice => unitPrice * quantity;

  /// Increments the quantity of this item.
  void increment() {
    quantity++;
  }

  /// Decrements the quantity of this item, ensuring it doesn't go below zero.
  void decrement() {
    if (quantity > 0) {
      quantity--;
    }
  }
}
