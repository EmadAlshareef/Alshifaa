
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_locales/flutter_locales.dart';
import 'package:flutter_paypal_checkout/flutter_paypal_checkout.dart';
import 'persistent_shopping_cart.dart';
import 'res/components/cart_tile_widget.dart';
import 'res/components/empty_cart_msg_widget.dart';






class CartView extends StatefulWidget {
  const CartView({Key? key}) : super(key: key);

  @override
  State<CartView> createState() => _CartViewState();
}

class _CartViewState extends State<CartView> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(

      appBar: AppBar(
          backgroundColor: Colors.blue,
          title: const LocaleText("My Cart"),



      ),
      body: SafeArea(
          child: Column(
            children: [
              Expanded(
                child: Container(
                  width: double.infinity,
              decoration: const BoxDecoration(
                  gradient:
                  LinearGradient(
                    colors:[Colors.blue , Colors.white],
                    begin: Alignment.topCenter,
                    end: Alignment.bottomLeft,
                  )
              ),
                  child: PersistentShoppingCart().showCartItems(
                    cartTileWidget: ({required data}) => CartTileWidget(data: data),
                    showEmptyCartMsgWidget: const EmptyCartMsgWidget(),
                  ),
                ),
              ),

                 PersistentShoppingCart().showTotalAmountWidget(
                  cartTotalAmountWidgetBuilder: (totalAmount) =>
                      Visibility(
                        visible: totalAmount == 0.0 ? false: true,
                        child: Column(
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                const Text('Total', style: TextStyle(color: Colors.black , fontSize: 22),),
                                Text(r"$"+totalAmount.toString(), style: const TextStyle(color: Colors.black , fontSize: 22),),
                              ],
                            ),
                            TextButton(
                              onPressed: () async {
                                Navigator.of(context).push(MaterialPageRoute(
                                  builder: (BuildContext context) => PaypalCheckout(
                                    sandboxMode: true,
                                    clientId: "AXNYVOzVJmzB5Glpq0lpbSfVG633trg3gyswT9Pgtbt__X-f1_MyrfHEL9vFbcZsAmHa7iCuFrOBihhu",
                                    secretKey: "ENg6OcM1KA2bTCDn8iLl5BDoRuNwMiGdZ3OahwdLi97I4tKTIUd8lAQ1y315lapH0_LKj14m2XggU_lg",
                                    returnURL: "success.snippetcoder.com",
                                    cancelURL: "cancel.snippetcoder.com",
                                    transactions: const [
                                      {
                                        "amount": {
                                          "total": '70',
                                          "currency": "USD",
                                          "details": {
                                            "subtotal": '70',
                                            "shipping": '0',
                                            "shipping_discount": 0
                                          }
                                        },
                                        "description": "The payment transaction description.",

                                        "item_list": {
                                          "items": [
                                            {
                                              "name": "Apple",
                                              "quantity": 4,
                                              "price": '5',
                                              "currency": "USD"
                                            },
                                            {
                                              "name": "Pineapple",
                                              "quantity": 5,
                                              "price": '10',
                                              "currency": "USD"
                                            }
                                          ],


                                        }
                                      }
                                    ],
                                    note: "Contact us for any questions on your order.",
                                    onSuccess: (Map params) async {
                                      print("onSuccess: $params");
                                    },
                                    onError: (error) {
                                      print("onError: $error");
                                      Navigator.pop(context);
                                    },
                                    onCancel: () {
                                      print('cancelled:');
                                    },
                                  ),
                                ));
                              },
                              style: TextButton.styleFrom(
                                backgroundColor: Colors.grey,
                                foregroundColor: Colors.black,
                                shape: const BeveledRectangleBorder(
                                  borderRadius: BorderRadius.all(
                                    Radius.circular(1),
                                  ),
                                ),
                              ),
                              child: const Text('go to paypal',
                                style: TextStyle(fontSize: 20,fontWeight:FontWeight.bold),),
                            ),
                          ],
                        ),
                      ),
                ),

            ],
          ),
        ),

    );
  }
}
