// example's lllHome.dart
import 'package:flutter/material.dart';
import 'package:flutter_locales/flutter_locales.dart';


import 'cart_view.dart';
import 'persistent_shopping_cart.dart';
import 'cart_model.dart';
import 'item_model.dart';
import 'res/components/network_image_widget.dart';
class ProductsScreen extends StatelessWidget {
  ProductsScreen({super.key});

  List<ItemModel> itemsList = const [
    ItemModel(productId: '1', productName: 'Collagen' ,productDescription: 'JD' , productThumbnail: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSb9Mwp5k19sqiCUenER6NQkC25SA0hZeDldw&s' , unitPrice: 5, ),
    ItemModel(productId: '2' ,productName: 'Omega3' ,productDescription: 'JD' , productThumbnail: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSQo473dtae6F6s8rRlGs-sFr64UvnN7JpQcg&s' , unitPrice: 3, ),
    ItemModel(productId: '3',productName: 'Magnesium' ,productDescription: 'JD' , productThumbnail: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQGWTgCVEPC6L1q0GVvVwFAbblm1vlIFnipAQ&s' , unitPrice: 4, ),
    ItemModel(productId: '4',productName: 'Vitamin_D' ,productDescription: 'JD' , productThumbnail: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR2m60n58NlK1F-8b_xU4JV94UzvuOB11-unA&s' , unitPrice: 10, ),
    ItemModel(productId: '5',productName: 'Cough Syrup' ,productDescription: 'JD' , productThumbnail: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTqA1z-yFIxW-hle_tiLOrytGDyCbC-qF22Ng&s' , unitPrice: 5, ),
    ItemModel(productId: '6',productName: 'Panadol Children' ,productDescription: 'JD' , productThumbnail: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQyk-BUKZ4DpaUhdYyXqTEZqwuCXWo5ZVw7SA&s' , unitPrice: 3 ),
    ItemModel(productId: '7',productName: 'Panadol' ,productDescription: 'JD' , productThumbnail: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTyFSY5JOo_NXzx6tZxGR3RWVLdqQ-B2Wwicg&s' , unitPrice: 2, ),
    ItemModel(productId: '8',productName: 'Aspirin' ,productDescription: 'JD' , productThumbnail: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQd_K2vBtQSYpLnSMR-d__9HDEHzBiRiroebg&s' , unitPrice: 6, ),
    ItemModel(productId: '9',productName: 'Face Cream ' ,productDescription: 'JD' , productThumbnail: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ8adusJSXz4emWhIh-gReKrPxjSW4xERp3Hw&s' , unitPrice: 12 ),
    ItemModel(productId: '10',productName: 'Vitamin C Serum' ,productDescription: 'JD' , productThumbnail: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ6ha8LoV6eUSFUim95F0ZrB0hqc36o7h0Xug&s' , unitPrice: 7, ),
  ] ;

  get primaryColor => null;

  @override
  Widget build(BuildContext context) {
    return Scaffold(

      backgroundColor: Colors.black,

      appBar: AppBar(

        title: const LocaleText( "phrmacy pro", style: TextStyle(fontSize: 20),),
        centerTitle: true,
        actions: [
          PersistentShoppingCart().showCartItemCountWidget(
            cartItemCountWidgetBuilder: (itemCount) => IconButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const CartView()),
                );
              },
              icon: Badge(
                label:Text(itemCount.toString()) ,
                child: const Icon(Icons.shopping_bag_outlined),
              ),
            ),
          ),
          const SizedBox(width: 20.0)
        ],
      ),
      body:

      Container(
        width: double.infinity,
        decoration: const BoxDecoration(
            gradient:
            LinearGradient(
              colors:[Colors.white54 , Colors.white],
              begin: Alignment.topCenter,
              end: Alignment.bottomLeft,
            )
        ),
        child: SafeArea(


          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 15),
            child: ListView.builder(

                itemCount: itemsList.length,
                itemBuilder: (context, index){
                  return Padding(
                    padding: const EdgeInsets.only(bottom: 5),
                    child: Card(
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              mainAxisSize: MainAxisSize.max,
                              children: [
                                NetworkImageWidget(
                                  height: 100,
                                  width: 100,
                                  imageUrl: itemsList[index].productThumbnail.toString(),
                                ),
                                const SizedBox(width: 10,),
                                Expanded(
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(itemsList[index].productName ,
                                        style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700 , color: Colors.black),
                                      ),
                                      Text(itemsList[index].productDescription ,
                                        maxLines: 2,
                                        style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w500,color: Colors.black),
                                      ),
                                      const SizedBox(height: 5,),
                                      Text(r"$"+itemsList[index].unitPrice.toString() ,
                                        style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w500 ,color: Colors.black),
                                      ),
                                      Align(
                                        alignment: Alignment.centerRight,
                                        child: PersistentShoppingCart().showAndUpdateCartItemWidget(
                                          inCartWidget: Container(
                                            height: 30,
                                            width: 70,
                                            decoration: BoxDecoration(
                                              borderRadius: BorderRadius.circular(20),
                                              border: Border.all(color: Colors.red),
                                            ),
                                            child: Center(
                                              child: LocaleText(
                                                "remove" ,
                                                style: Theme.of(context).textTheme.bodySmall,
                                              ),
                                            ),
                                          ),
                                          notInCartWidget: Container(
                                            height: 30,
                                            width: 100,
                                            decoration: BoxDecoration(
                                              border: Border.all(color: Colors.green),
                                              borderRadius: BorderRadius.circular(20),
                                            ),
                                            child: Padding(
                                              padding: const EdgeInsets.symmetric(horizontal: 5),
                                              child: Center(
                                                child: LocaleText(
                                                  "add cart"  ,
                                                  style: Theme.of(context).textTheme.bodySmall,
                                                ),
                                              ),
                                            ),
                                          ),
                                          product: PersistentShoppingCartItem(
                                              productId: index.toString(),
                                              productName: itemsList[index].productName,
                                              productDescription: itemsList[index].productDescription,
                                              unitPrice: double.parse(itemsList[index].unitPrice.toString()),
                                              productThumbnail: itemsList[index].productThumbnail.toString(),
                                              quantity: 2
                                          ),
                                        ),
                                      )
                                    ],
                                  ),
                                )

                              ],
                            )
                          ],
                        ),
                      ),
                    ),
                  );
                }),
          ),
        ),
      ),

    );
  }
}

