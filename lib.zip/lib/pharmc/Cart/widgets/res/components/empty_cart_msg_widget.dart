import 'package:flutter/material.dart';
import 'package:flutter_locales/flutter_locales.dart';

class EmptyCartMsgWidget extends StatelessWidget {
  const EmptyCartMsgWidget({super.key});

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Center(
        child: SizedBox(
          height: size.height * .7,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const LocaleText("cart empty"),
              const SizedBox(height: 20),
              ElevatedButton(
              onPressed: () {
                Navigator.pop(context);
              },
              child: const LocaleText("shop now")),
        ],
      ),
    ));
  }
}
