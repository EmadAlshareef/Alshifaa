import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_locales/flutter_locales.dart';

class Product {
  final String id , title  , description;
  final double price ;
  final Color color ;
  final int  size;
  final String image;
  const Product({
    required this.color,
    required this.id,
    required this.title,
    required this.size,
    required this.description,
    required this.price ,
    required this.image,
  });
}

List<Product> products = const [

   Product(
      id: '1',
      title: ' Omega3' ,
    description:"Omega-3 is Essential fatty acids crucial for optimal health, primarily found in fish oil and certain plant sources. Known for their anti-inflammatory properties, omega-3 fatty acids support heart health, brain function, and overall well-being. They play a key role in reducing the risk of chronic diseases and promoting healthy development throughout life.",

      image:  "images/omega.jpg",
      price: 3, size:12,
      color:Color(0xFF989493)
  ),
  Product(id: '2', title: ' Collagen' ,description:"Collagen is a vital protein that serves as the foundation for skin, bones, muscles, and more. Known for its structural support and elasticity, collagen promotes tissue strength and resilience, aiding in skin health, joint function, and overall well-being." , image:  "images/collagin.jpg", price: 5, size:20, color:Color(0xFFFB7883) ),

  Product(id: '5', title: ' Cough Syrup' ,description: "Cough Syrup is a medicinal liquid formulation designed to alleviate cough symptoms, typically containing active ingredients such as cough suppressants, expectorants, antihistamines, or decongestants. Cough syrups work by soothing irritated throat tissues, loosening mucus, or suppressing the cough reflex. They provide relief from coughing associated with various respiratory conditions such as colds, flu, allergies, and bronchitis." , image:  "images/coughsyrup.jpeg", price: 5, size:21, color:Color(0xFFFB7883) ),
  Product(id: '4', title: ' Vitamin_D' ,description:  "Vitamin D is a crucial nutrient that plays various roles in the body. It helps regulate calcium and phosphate levels, promoting healthy bones and teeth. Additionally, it supports immune function, mood regulation, and muscle health. While sunlight exposure is a primary source, it can also be obtained from certain foods and supplements." , image:  "images/vitamen_d.jpg", price: 10, size:16, color:Color(0xFFD3A984) ),

  Product(id: '9', title: ' Face Cream' ,description: "Face Cream is a skincare product designed to nourish, hydrate, and protect facial skin. Typically containing a combination of moisturizing ingredients, antioxidants, vitamins, and sometimes specialized compounds like retinol or hyaluronic acid. Face creams aim to improve skin texture, reduce signs of aging, and enhance overall complexion by providing hydration, combating free radicals, and promoting skin renewal. They're an essential part of daily skincare routines to maintain healthy, youthful-looking skin" , image:  "images/facecream.jpeg", price: 12, size:10, color:Color(0xFFE6B398) ),

  Product(id: '7', title: ' Panadol' ,description:
  "Panadol tablets fight against pain such as headache, muscle pain, backache, toothache and period pain.This medication also reduces fever and pain associated with colds and flu.",
  image:  "images/panadol.jpg", price: 2, size:11, color:Color(0xFFD3A984) ),

  Product(id: '8', title: ' Aspirin' ,description:  "Aspirin: A versatile medication with pain-relieving, anti-inflammatory, and fever-reducing properties. It's commonly used to alleviate minor aches, pains, and fevers. Aspirin also helps prevent blood clots and reduce the risk of heart attacks and strokes when taken regularly under medical guidance." , image:  "images/Aspirin.jpg", price: 6, size:12, color:Color(0xFF989493) ),
  Product(id: '3', title: ' Magnesium' ,description: "Magnesium a Essential mineral vital for muscle, nerve, and bone health. Supports over 300 bodily functions, including energy production and relaxation. Found in nuts, seeds, greens, and supplements" , image:  "images/magnesium.jpg", price: 4, size:18, color:Color(0xFFD3A984) ),
  Product(id: '6', title: ' Panadol Children' ,description:  "Children’s Panadol is Australia’s leading brand for children’s pain relief1. For over 60 years, Children’s Panadol has given parents the confidence to help their kids feel better. With Children’s Panadol Baby Drops, you can be rest assured knowing that it works fast on children’s pain and fever. The active ingredient in Children’s Panadol is paracetamol.",
      image:  "images/pandolchildren.jpg", price: 3, size:9, color:Color(0xFF989493) ),
  Product(id: '10', title: ' Vitamin C Serum' ,description: "Vitamin C Serum a skincare powerhouse, packed with antioxidant-rich vitamin C to brighten skin, reduce wrinkles, and protect against environmental damage." , image:  "images/collagen-vc.png", price: 7, size:32, color:Color(0xFFFB7883) ),

] ;