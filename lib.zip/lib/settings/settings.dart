import 'package:flutter/material.dart';
import 'package:flutter_locales/flutter_locales.dart';
import 'package:google_fonts/google_fonts.dart';
import '../Booked Appointment/Bookeddddd/app/app.dart';
import '../Booked Appointment/Doctors.dart';
import '../bank/payment.dart';
import '../home Visit/HomeVisitDetails/pages/todosHome.dart';
import '../home Visit/medical.dart';

import '../maps/googlemaplocations.dart';
import '../screens/asset.dart';
import 'FeedBackDetails/pages/todosFeed.dart';
import 'editProfile.dart';
import 'langauge.dart';
class settings extends StatelessWidget {
  const settings({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(

      appBar: AppBar(
        centerTitle: true,
        title:LocaleText(
          "setting" ,
          style: GoogleFonts.lato(
            textStyle: Theme.of(context).textTheme.displayLarge,
            fontSize: 26,
            fontWeight: FontWeight.w700,
            fontStyle: FontStyle.italic,
          ),
        ),
        backgroundColor: hexStringToColor("5E61F4"),
      ),
      body:
      Container(
        width: double.infinity,

        decoration: BoxDecoration(
            gradient: LinearGradient(colors: [
              hexStringToColor("5E61F4"),
              hexStringToColor("9546C4"),

            ], begin: Alignment.topCenter, end: Alignment.bottomCenter)),
        child: SingleChildScrollView(
          scrollDirection: Axis.vertical,
          child: Column(
            children: [
              Column(
                children: [
                  Container(

                    child:LocaleText(
                      "account",
                      style: GoogleFonts.lato(
                        textStyle: Theme.of(context).textTheme.displayLarge,
                        fontSize: 26,
                        fontWeight: FontWeight.w700,
                        fontStyle: FontStyle.italic,
                      ),
                    ),
                  ),
                  TextButton(
                    onPressed: () {
                      Navigator.push(context,
                        MaterialPageRoute(
                          builder: (context)=>EditProfilePage(),),);
                    },
                    child:const LocaleText(
                      "Edit" ,
                      style: TextStyle(
                          fontSize: 15,
                          fontWeight: FontWeight.bold,
                          color: Colors.black


                      ),
                    ),
                  ),
                  SizedBox(height: 10,),
                  TextButton(
                    onPressed: () {
                      Navigator.push(context,
                        MaterialPageRoute(
                          builder: (context)=>TodosPageHomeVisit(),),);
                    },
                    child:const LocaleText(
                      "MY"  ,
                      style: TextStyle(
                          fontSize: 15,
                          fontWeight: FontWeight.bold,
                          color: Colors.black
                      ),
                    ),
                  ),
                  SizedBox(height: 10,),
                  TextButton(
                    onPressed: () {
                      Navigator.push(context,
                        MaterialPageRoute(
                          builder: (context)=>CustomMarkerScreen(),),);
                    },
                    child:const LocaleText (
                      "Record",
                      style: TextStyle(
                          fontSize: 15,
                          fontWeight: FontWeight.bold,
                          color: Colors.black


                      ),
                    ),
                  ),
                  SizedBox(height: 10,),

                ],
              ),
              SizedBox(height: 20,),
              Column(
                children: [
                  Container(

                    child:const LocaleText("Support",
                      style: TextStyle(

                          fontSize: 35,
                          fontWeight: FontWeight.bold,
                          color: Colors.black),),
                  ),
                  TextButton(
                    onPressed: () {
                      Navigator.push(context,
                        MaterialPageRoute(
                          builder: (context)=>rrr(),),);
                    },
                    child:const LocaleText (
                      "Help",
                      style: TextStyle(
                          fontSize: 17,
                          fontWeight: FontWeight.bold,
                          color: Colors.black


                      ),
                    ),
                  ),
                  SizedBox(height: 10,),
                  TextButton(
                    onPressed: () {
                      Navigator.push(context,
                        MaterialPageRoute(
                          builder: (context)=>Doctors(),),);
                    },
                    child:const LocaleText(
                      "Term" ,
                      style: TextStyle(
                          fontSize: 15,
                          fontWeight: FontWeight.bold,
                          color: Colors.black


                      ),
                    ),
                  ),
                  SizedBox(height: 10,),
                  TextButton(
                    onPressed: () {
                      Navigator.push(context,
                        MaterialPageRoute(
                          builder: (context)=>CheckoutPage(),),);
                    },
                    child: const LocaleText(
                      "Payments",
                      style: TextStyle(
                          fontSize: 15,
                          fontWeight: FontWeight.bold,
                          color: Colors.black


                      ),
                    ),
                  ),
                  SizedBox(height: 10,),

                ],
              ),
              SizedBox(height: 20,),
              Column(
                children: [
                  Container(

                    child: const LocaleText("Act",
                      style: TextStyle(

                          fontSize: 35,
                          fontWeight: FontWeight.bold,
                          color: Colors.black),),
                  ),
                  TextButton(
                    onPressed: () {
                      Navigator.push(context,
                        MaterialPageRoute(
                          builder: (context)=>TodosPageFeed(),),);
                    },
                    child: const LocaleText(
                      "fead" ,
                      style: TextStyle(
                          fontSize: 15,
                          fontWeight: FontWeight.bold,
                          color: Colors.black


                      ),
                    ),
                  ),
                  SizedBox(height: 10,),
                  TextButton(
                    onPressed: () {
                      Navigator.push(context,
                        MaterialPageRoute(
                          builder: (context)=>languages(),),);
                    },
                    child: const LocaleText(
                      "lang",
                      style: TextStyle(
                          fontSize: 15,
                          fontWeight: FontWeight.bold,
                          color: Colors.black


                      ),
                    ),
                  ),
                  SizedBox(height: 10,),
                  TextButton(
                    onPressed: () {
                      Navigator.push(context,
                        MaterialPageRoute(
                          builder: (context)=>HomeScreen(),),);
                    },
                    child: const LocaleText(
                      "logu",
                      style: TextStyle(
                          fontSize: 15,
                          fontWeight: FontWeight.bold,
                          color: Colors.black


                      ),
                    ),
                  ),
                  SizedBox(height: 10,),

                ],
              ),

            ],
          ),
        ),


      ),

    );
  }
}

hexStringToColor(String hexColor) {
  hexColor = hexColor.toUpperCase().replaceAll("#", "");
  if (hexColor.length == 6) {
    hexColor = "FF" + hexColor;
  }
  return Color(int.parse(hexColor, radix: 16));
}