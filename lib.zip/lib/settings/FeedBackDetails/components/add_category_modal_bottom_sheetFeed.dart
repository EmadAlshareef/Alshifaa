import 'package:flutter/material.dart';
import 'package:flutter_locales/flutter_locales.dart';

class AddCategoryModalBottomSheetFeed extends StatelessWidget {
  const AddCategoryModalBottomSheetFeed({super.key});

  @override
  Widget build(BuildContext context) {
    TextEditingController controller = TextEditingController();
    return Padding(
      padding: const EdgeInsets.all(10),
      child: Row(
        children: [
          Expanded(
            child: TextField(
              controller: controller,
              decoration: const InputDecoration(
                  hintText: "Doctors", hintStyle: TextStyle(fontSize: 12)),
              style: const TextStyle(fontSize: 12),
            ),
          ),
          MaterialButton(
            color: Theme.of(context).primaryColor,
            onPressed: () {
              Navigator.pop(context, controller.text);
            },
            child: const LocaleText("add", style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
  }
}
