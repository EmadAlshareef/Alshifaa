import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_locales/flutter_locales.dart';
import 'package:intl/intl.dart';
import 'package:line_icons/line_icons.dart';
import 'package:provider/provider.dart';
import 'package:untitled1/settings/FeedBackDetails/components/todo_property_rowfeed.dart';

import '../pages/categoriesFeed.dart';
import '../providers/todo_providerFeed.dart';

class AddTaskModalBottomSheetFeed extends StatefulWidget {
  const AddTaskModalBottomSheetFeed({super.key});

  @override
  State<AddTaskModalBottomSheetFeed> createState() =>
      _AddTaskModalBottomSheetFeedState();
}

class _AddTaskModalBottomSheetFeedState extends State<AddTaskModalBottomSheetFeed> {
  String date = "";
  String time = "";
  String category = "";


  TextEditingController titleController = TextEditingController();
  TextEditingController descriptionController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    final provider = Provider.of<TodoProviderFeed>(context);
    ThemeData themeData = Theme.of(context).copyWith(
      colorScheme: ColorScheme.light(primary: Theme.of(context).primaryColor),
    );

    return Padding(
      padding: const EdgeInsets.only(top: 10, right: 40, left: 40),
      child: Column(children: [
          SingleChildScrollView(
          physics: BouncingScrollPhysics(),
        child:TextField(
          controller: titleController,
          decoration: const InputDecoration(
            hintText: "Name",),
          style: const TextStyle(fontSize: 12),
        ),),
        Padding(
          padding: const EdgeInsets.only(top: 20, bottom: 20),
          child: TextField(
            controller: descriptionController,
            decoration: const InputDecoration(hintText: "Write Your FeedBack and Your Phone Number"),
            style: const TextStyle(fontSize: 12),
          ),
        ),


        SingleChildScrollView(
          scrollDirection: Axis.vertical,
          child: Column(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            SingleChildScrollView(
              scrollDirection: Axis.vertical,
              child: Column(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [


                IconButton(
                  onPressed: () async {
                    await Navigator.of(context)
                        .push(MaterialPageRoute(
                      builder: (context) => const CategoryBoxFeed(isSelecting: true,),
                    ))
                        .then((value) {
                      setState(() {
                        category = value;

                      });
                    });
                  },
                  icon: const Icon(LineIcons.tag),
                ),
              LocaleText("set problem"),
                TodoPropertyRowFeed(
                    property: category,
                    onDelete: () {
                      setState(() {
                        category = "";
                      });
                    }),

              ]),),
            IconButton(
              onPressed: () {
                if (titleController.text.isNotEmpty) {
                  provider.addTodo(titleController.text.trim(),
                      descriptionController.text.trim(), date, time, category);
                }
                Navigator.of(context).pop();
              },
              icon: const Icon(LineIcons.paperPlane),
            ),
            LocaleText("Confirm"),
            SizedBox(height: 200,)
          ]),
        ),
      ]),

    );
  }
}
