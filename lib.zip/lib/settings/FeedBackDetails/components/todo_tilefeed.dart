import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_locales/flutter_locales.dart';
import 'package:line_icons/line_icons.dart';
import 'package:provider/provider.dart';

import '../models/todoFeed.dart';
import '../pages/todoFeed.dart';
import '../providers/todo_providerFeed.dart';

class TodoTileFeed extends StatefulWidget {
  final TodoFeed todoHomeVisit;
  const TodoTileFeed({super.key, required this.todoHomeVisit});

  @override
  State<TodoTileFeed> createState() => _TodoTileFeedState();
}

class _TodoTileFeedState extends State<TodoTileFeed> {
  @override
  Widget build(BuildContext context) {
    final provider = Provider.of<TodoProviderFeed>(context);
    final todo = widget.todoHomeVisit;

    return SingleChildScrollView(
        physics: BouncingScrollPhysics(),
    child:SizedBox(
      height: 170,
      child: Card(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        elevation: 2,
        child: Padding(
          padding: const EdgeInsets.all(10),
          child: Row(crossAxisAlignment: CrossAxisAlignment.start,
              children: [
            InkWell(
              onTap: () => provider.toggleIsComplete(todo),
              child: Icon(
                todo.isComplete ? LineIcons.checkCircle : LineIcons.circle,
                size: 25,
              ),
            ),
            const Padding(padding: EdgeInsets.only(right: 20)),
            Expanded(
              child: InkWell(
                onTap: () => Navigator.of(context).push(
                  MaterialPageRoute(builder: (context) => TodoPageFeed(todo: todo)),
                ),
                child: Column(


                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Padding(
                              padding: const EdgeInsets.only( bottom: 10),
                              child: Text(
                                todo.title,
                                style: const TextStyle(
                                    fontWeight: FontWeight.bold, fontSize: 20),
                              ),
                            ),
                            SizedBox(width: 10,),
                            InkWell(
                              onTap: () => provider.toggleToBeDeleted(todo),
                              child: todo.toBeDeleted
                                  ? const LocaleText("Restore")
                                  : const Text(""),
                            ),
                          ],
                        ),
                        SingleChildScrollView(
                          scrollDirection: Axis.vertical,
                          child:  Column(children: [
                              Visibility(
                                visible: todo.date != provider.currentDateHome,
                                child:Text(
                                    widget.todoHomeVisit.date
                                            .contains(DateTime.now().year.toString())
                                        ? todo.date.replaceAll(
                                            RegExp(", ${DateTime.now().year}"),
                                            todo.time.isNotEmpty ? ", " : "")
                                        : todo.date,
                                    style: const TextStyle(
                                      fontSize: 16,
                                    ),
                                  ),
                                ),

                              Padding(
                                padding: const EdgeInsets.only(bottom: 8.0),
                                child: Text(
                                  todo.time,
                                  style: const TextStyle(
                                    fontSize: 16,
                                  ),
                                ),
                              ),
                            Padding(
                              padding: const EdgeInsets.only(bottom: 8.0),
                              child: Text(
                                todo.date,
                                style: const TextStyle(
                                  fontSize: 16,
                                ),
                              ),
                            ),
                              Text(
                                todo.category,
                                style: const TextStyle(fontSize: 12, color: Colors.grey),
                              ),

                            ]),
                          ),

                      ]),
                ),
            ),
              ],
            )
          ,
        ),
      ),)
    );
  }
}
