import 'package:flutter/material.dart';
import 'package:flutter_locales/flutter_locales.dart';
import 'package:provider/provider.dart';
import 'package:untitled1/settings/FeedBackDetails/components/todo_tilefeed.dart';
import 'package:untitled1/settings/FeedBackDetails/models/todoFeed.dart';
import 'package:untitled1/settings/FeedBackDetails/providers/todo_providerFeed.dart';

import '../../../Booked Appointment/clinics.dart';


class CompletedTodosPageFeedBack extends StatelessWidget {
  const CompletedTodosPageFeedBack({super.key});

  @override
  Widget build(BuildContext context) {
    final provider = Provider.of<TodoProviderFeed>(context);
    final List<TodoFeed> completedTodos = provider.completedTodos;

    return Scaffold(
        appBar: AppBar(
          backgroundColor: hexStringToColor("5E61F4"),
          centerTitle: true,
          title: LocaleText("feedBacks",style: TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 26,

          ),),
        ),

           body:Container(
               width: double.infinity,

               decoration: BoxDecoration(
                   gradient: LinearGradient(colors: [
                     hexStringToColor("5E61F4"),
                     hexStringToColor("9546C4"),

                   ], begin: Alignment.topCenter, end: Alignment.bottomCenter)),
               child:  Visibility(
      replacement: const Center(
        child: LocaleText("no feadbacks",style: TextStyle(
          fontWeight: FontWeight.bold,
          fontSize: 20,

        ),),
      ),
      visible: completedTodos.isNotEmpty,
      child: Padding(
        padding: const EdgeInsets.all(30),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          LocaleText ("${completedTodos.length} Confirmed"),
          const Divider(),
          const Padding(padding: EdgeInsets.only(bottom: 10)),
          Expanded(
            child: ListView.builder(
              itemCount: completedTodos.length,
              itemBuilder: (context, index) => TodoTileFeed(
                todoHomeVisit: completedTodos[index],
              ),
            ),
          ),
        ]),
      ),
    )
  )
);
}
}
