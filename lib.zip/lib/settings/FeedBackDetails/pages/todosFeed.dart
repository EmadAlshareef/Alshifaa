import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:flutter_locales/flutter_locales.dart';
import 'package:line_icons/line_icons.dart';
import 'package:provider/provider.dart';
import '../../../Booked Appointment/Bookeddddd/screens/home_screen.dart';
import '../components/add_todo_modal_bottom_sheetFeed.dart';
import '../components/todo_tilefeed.dart';
import '../providers/todo_providerFeed.dart';



class TodosPageFeed extends StatelessWidget {
  const TodosPageFeed({super.key});



  @override
  Widget build(BuildContext context) {
    final provider = Provider.of<TodoProviderFeed>(context);
    var todosHomeVisit = provider.allTodos;

    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        backgroundColor:hexStringToColor("5E61F4"),
        centerTitle: true,
        title: LocaleText("feadback",style: TextStyle(
          fontSize: 24,
          fontWeight: FontWeight.bold,
        ),),
      ),
      floatingActionButton:  FloatingActionButton(
          backgroundColor: Colors.blue,
          onPressed: () => showModalBottomSheet(
            context: context,
            builder: (BuildContext context) =>
                SingleChildScrollView(
                    physics: BouncingScrollPhysics(),
                    child: const Wrap(children:  [AddTaskModalBottomSheetFeed()])),
          ),
          child: const Icon(
            LineIcons.plus,
          ),
        ),

      body:Container(
        width: double.infinity,

        decoration: BoxDecoration(
            gradient: LinearGradient(colors: [
              hexStringToColor("5E61F4"),
              hexStringToColor("9546C4"),

            ], begin: Alignment.topCenter, end: Alignment.bottomCenter)),
        child:  Padding(
        padding: const EdgeInsets.all(30),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Expanded(
            child: Padding(
              padding: const EdgeInsets.only(top:0),
              child: Visibility(
                visible: todosHomeVisit.isNotEmpty,
                replacement: const Center(
                  child: LocaleText("plus feadback", style:
                  TextStyle( fontSize: 26,
                      fontWeight:FontWeight.bold,
                      letterSpacing: 0.1),
                  ),
                ),
                child:
                SingleChildScrollView(
                  physics: BouncingScrollPhysics(),
                  child:ListView.builder(
                    shrinkWrap: true,
                    itemCount: todosHomeVisit.length,
                    itemBuilder: (context, index) =>
                        TodoTileFeed(todoHomeVisit: todosHomeVisit[index])),
              ),
            ),
          ),)

        ]),
      ),
      ),
    );
  }
}