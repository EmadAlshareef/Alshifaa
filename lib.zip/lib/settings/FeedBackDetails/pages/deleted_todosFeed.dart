import 'package:flutter/material.dart';
import 'package:flutter_locales/flutter_locales.dart';
import 'package:provider/provider.dart';
import '../components/todo_tilefeed.dart';
import '../models/todoFeed.dart';
import '../providers/todo_providerFeed.dart';

class DeletedTodosPageFeed extends StatelessWidget {
  const DeletedTodosPageFeed({super.key});

  @override
  Widget build(BuildContext context) {
    final provider = Provider.of<TodoProviderFeed>(context);
    final List<TodoFeed> deletedTodos = provider.deletedTodos;

    return Visibility(
      replacement:
          const Center(child: LocaleText("not deleted ")),
      visible: deletedTodos.isNotEmpty,
      child: Padding(
        padding: const EdgeInsets.all(30),
        child: Column(children: [
          Expanded(
            child: ListView.builder(
              itemCount: deletedTodos.length,
              itemBuilder: (context, index) => TodoTileFeed(
                todoHomeVisit: deletedTodos[index],
              ),
            ),
          ),
        ]),
      ),
    );
  }
}
