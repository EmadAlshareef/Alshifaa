import 'package:flutter/material.dart';
import 'package:flutter_locales/flutter_locales.dart';
import 'package:geolocator/geolocator.dart';
import 'package:line_icons/line_icons.dart';
import 'package:provider/provider.dart';
import 'package:untitled1/settings/FeedBackDetails/components/add_category_modal_bottom_sheetFeed.dart';


import '../../../home Visit/HomeVisitDetails/components/delete_buttonHome.dart';
import '../providers/todo_providerFeed.dart';


class CategoryBoxFeed extends StatefulWidget {
  const CategoryBoxFeed({ super.key,
  required this.isSelecting});
  final bool isSelecting;

  @override
  State<CategoryBoxFeed> createState() => _CategoryBoxFeedState();
}

class _CategoryBoxFeedState extends State<CategoryBoxFeed> {


  @override
  Widget build(BuildContext context) {
    final provider = Provider.of<TodoProviderFeed>(context);
    var categories = provider.categoriesHome;
    String selectedCategory = "";
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        leading: IconButton(
            onPressed: () => Navigator.pop(context, selectedCategory),
            icon: const Icon(LineIcons.backspace, color: Colors.black)),
        title: const LocaleText(
          "fead" ,
          style: TextStyle(
              fontWeight: FontWeight.bold, fontSize: 30, color: Colors.black),
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () async {
          await showModalBottomSheet(
            context: context,
            builder: (context) =>
                Wrap(children: [AddCategoryModalBottomSheetFeed()]),
          ).then((value) => provider.addCategory(value));
        },
        backgroundColor: Theme.of(context).primaryColor,
        child: const Icon(LineIcons.plus),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(children: [
          Expanded(
            child: ListView.builder(
              itemCount: categories.length,
              itemBuilder: (context, index) => Row(
                children: [
                  Text(
                    categories[index],
                    style: const TextStyle(fontSize: 13),
                  ),
                  const Spacer(),
                  IconButton(
                      onPressed: () {
                        selectedCategory = categories[index];
                        Navigator.pop(context, selectedCategory);
                      },
                      icon: const Icon(LineIcons.plus, size: 20)),
                  DeleteButtonHomeVisit(
                    onTap: () => provider.removeCategory(categories[index]),
                  )
                ],
              ),
            ),
          ),
        ]),
      ),
    );
  }
}
