import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../models/todoFeed.dart';

class TodoProviderFeed extends ChangeNotifier {
  String currentDateHome = DateFormat.yMMMd().format(DateTime.now());
  List<String> categoriesHome =
  ["Pharmacy","Home Visit","Book Home","Call You Back"];

  //test data
  List<TodoFeed> allTodos = [
  ];

  List<TodoFeed> get deletedTodos {
    return allTodos.where((element) => element.toBeDeleted).toList();
  }

  List<TodoFeed> get completedTodos {
    return allTodos
        .where((element) => element.isComplete && !element.toBeDeleted)
        .toList();
  }



  void addTodo(String title, String description, String date, String time,
      String category) {
    allTodos.add(TodoFeed(
        title: title,
        date: date,
        description: description,
        time: time,
        category: category));
    notifyListeners();
  }

  void toggleToBeDeleted(TodoFeed todo) {
    todo.toBeDeleted = !todo.toBeDeleted;
    notifyListeners();
  }

  void toggleIsComplete(TodoFeed todo) {
    todo.isComplete = !todo.isComplete;
    notifyListeners();
  }

  List<TodoFeed> getSearchResults(String task) {
    return allTodos
        .where((element) =>
            RegExp(task, caseSensitive: false).hasMatch(element.title))
        .toList();
  }

  void addCategory(double category) {
    categoriesHome.add(category as String);
    notifyListeners();
  }

  void removeCategory(String category) {
    categoriesHome.remove(category);
    notifyListeners();
  }
}
