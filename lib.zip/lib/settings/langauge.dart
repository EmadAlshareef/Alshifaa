import 'package:flutter/cupertino.dart';
 import 'package:flutter/material.dart';
import 'package:flutter_locales/flutter_locales.dart';
import 'package:untitled1/settings/settings.dart';



 import '../screens/asset.dart';

 class languages extends StatefulWidget {
  const languages({super.key});

  @override
  State<languages> createState() => _languagesState();
 }

 class _languagesState extends State<languages> {
  @override
   List locales = [
    "English",
    "العربي"
  ];


   List localeCodes = [
    "en",
    "ar"
  ];
   int currentIndex = 0;

   bool selectedLocale = false;
  Widget build(BuildContext context) {

     return Scaffold(
       appBar: AppBar(
        title: LocaleText("setting"),
         backgroundColor:hexStringToColor("5E61F4"),
         elevation: 1,
        leading: BackButton(
           onPressed: () {
            Navigator.push(context,
              MaterialPageRoute(
                 builder: (context) => HomeScreen(),),);
           },
        ),
        actions: [
           IconButton(
            icon: Icon(
              Icons.settings,

            ),
             onPressed: () {
              Navigator.of(context).push(MaterialPageRoute(
                  builder: (BuildContext context) => settings()));
            },
          ),
        ],
       ),
      body: Container(
        width: double.infinity,

        decoration: BoxDecoration(
            gradient: LinearGradient(colors: [
              hexStringToColor("5E61F4"),
              hexStringToColor("9546C4"),

            ], begin: Alignment.topCenter, end: Alignment.bottomCenter)),
        child: Center(
          child: ListView.builder(
              shrinkWrap: true,
              itemCount: locales.length,
              itemBuilder: (context, index) {
                 selectedLocale = currentIndex == index;
                return Container(
                  margin: const EdgeInsets.all(8),
                   decoration: BoxDecoration(
                    color: Colors.blue,
                    borderRadius: BorderRadius.circular(8),

                  ),
                  child: ListTile(
                    onTap: () {
                       setState(() {
                         currentIndex = index;
                       });
                      Locales.change(context, localeCodes[currentIndex]);
                    },
                    leading: Icon(selectedLocale? Icons.check : Icons.language,color: Colors.white,),
                    title: Text(locales[index],style: const TextStyle(color: Colors.white),),
                    trailing: const Icon(Icons.arrow_forward_ios_rounded,size: 15,color: Colors.white,),

                  ),

                );
             }


           ),
        ),
      ),


    );
   }
}
hexStringToColor(String hexColor) {
  hexColor = hexColor.toUpperCase().replaceAll("#", "");
  if (hexColor.length == 6) {
    hexColor = "FF" + hexColor;
  }
  return Color(int.parse(hexColor, radix: 16));
}